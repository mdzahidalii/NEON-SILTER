/**
 * NEON SLITHER - Server-Authoritative Real-Time Multiplayer Arena
 * Features:
 * - 30 Hz server simulation physics tick
 * - Spatial Hash Grid for O(1) collision detection (thousands of pellets + dozens of snakes)
 * - Head-to-body collision detection with instant fair kill/death resolution
 * - Autonomous AI bot snakes to maintain 20-25 active arena combatants at all times
 * - Special Moving Pellets ("Neon Wisps") with reactive threat evasion
 * - Rich death pellet explosion scattering
 * - Delta-compressed network sync packets
 */

class SpatialGrid {
    constructor(cellSize = 200) {
        this.cellSize = cellSize;
        this.cells = new Map();
    }

    _key(cx, cy) {
        return `${cx}_${cy}`;
    }

    clear() {
        this.cells.clear();
    }

    insert(id, x, y, data) {
        const cx = Math.floor(x / this.cellSize);
        const cy = Math.floor(y / this.cellSize);
        const key = this._key(cx, cy);
        if (!this.cells.has(key)) {
            this.cells.set(key, []);
        }
        this.cells.get(key).push({ id, x, y, data });
    }

    queryNearby(x, y, radius) {
        const minCx = Math.floor((x - radius) / this.cellSize);
        const maxCx = Math.floor((x + radius) / this.cellSize);
        const minCy = Math.floor((y - radius) / this.cellSize);
        const maxCy = Math.floor((y + radius) / this.cellSize);
        const results = [];
        const rSq = radius * radius;

        for (let cx = minCx; cx <= maxCx; cx++) {
            for (let cy = minCy; cy <= maxCy; cy++) {
                const key = this._key(cx, cy);
                const cell = this.cells.get(key);
                if (cell) {
                    for (let i = 0; i < cell.length; i++) {
                        const item = cell[i];
                        const dx = item.x - x;
                        const dy = item.y - y;
                        if (dx * dx + dy * dy <= rSq) {
                            results.push(item);
                        }
                    }
                }
            }
        }
        return results;
    }
}

const BOT_NAMES = [
    'NeonKing', 'CyberViper', 'GlowMaster', 'NightCrawler', 'ViperX',
    'PlasmaHydra', 'LaserBite', 'AeroPhantom', 'QuantumWorm', 'ByteNommer',
    'HyperCoil', 'SynthStalker', 'AetherSerpent', 'NovaCobra', 'Solaris',
    'Ghost_Runner', 'Zenith', 'ZeroGravity', 'Omega_Hydra', 'ApexPredator',
    'VoltSerpent', 'RadiantBoa', 'EchoPulse', 'ShadowFang', 'GlitchWorm',
    'VenomMatrix', 'TitanPython', 'CosmicEel', 'PrismAdder', 'AbyssCrawler',
    'StarlightBoa', 'PulseViper', 'NeonEclipse', 'VortexMamba', 'SpecterWorm',
    'ChronoSerpent', 'InfernoCoil', 'AstralDrake', 'CyberBeast', 'OrbitalFang'
];

const SKINS = [
    { id: 'neon-blue', name: 'Neon Blue', primary: '#0284c7', secondary: '#0369a1', glow: '#0284c7' },
    { id: 'cyber-purple', name: 'Cyber Purple', primary: '#8b5cf6', secondary: '#7c3aed', glow: '#8b5cf6' },
    { id: 'electric-green', name: 'Electric Green', primary: '#10b981', secondary: '#059669', glow: '#10b981' },
    { id: 'hot-pink', name: 'Hot Pink', primary: '#ec4899', secondary: '#db2777', glow: '#ec4899' },
    { id: 'plasma-orange', name: 'Plasma Orange', primary: '#f97316', secondary: '#ea580c', glow: '#f97316' },
    { id: 'laser-red', name: 'Laser Red', primary: '#ef4444', secondary: '#dc2626', glow: '#ef4444' },
    { id: 'ice-cyan', name: 'Ice Cyan', primary: '#06b6d4', secondary: '#0891b2', glow: '#06b6d4' },
    { id: 'toxic-lime', name: 'Toxic Lime', primary: '#84cc16', secondary: '#65a30d', glow: '#84cc16' }
];

const FOOD_COLORS = ['#10b981', '#06b6d4', '#8b5cf6', '#ec4899', '#f97316', '#eab308', '#3b82f6', '#ef4444', '#14b8a6'];

class ArenaServer {
    constructor() {
        this.radius = 4500;
        this.targetSnakeCount = 20; // Beginner-friendly: spacious arena with 20 active snakes
        this.targetFoodCount = 850; // Measured, clean food density without clutter
        this.targetWispCount = 6;

        this.snakes = new Map(); // id -> Snake instance
        this.foods = new Map();  // id -> Food instance
        this.wisps = new Map();  // id -> Wisp instance
        this.clients = new Map();// socket -> playerSnake

        this.foodGrid = new SpatialGrid(220);
        this.snakeGrid = new SpatialGrid(160);
        this.foodSpawnTimer = 0;
        this.decayTimer = 0;
        this.nextFoodId = 1;
        this.nextWispId = 1;
        this.nextSnakeId = 1;

        // Delta tracking for network efficiency
        this.eatenFoodIds = [];
        this.newFoods = [];
        this.killFeed = [];

        this.lastTickTime = Date.now();
        this.tickCount = 0;

        this.initWorld();
        this.startLoop();
    }

    initWorld() {
        // Distribute initial food evenly in concentric rings across entire map to prevent clustering
        const numRings = 13;
        for (let r = 1; r <= numRings; r++) {
            const ringDist = (r / numRings) * (this.radius * 0.94);
            const numPellets = Math.round(8 + r * 5);
            for (let p = 0; p < numPellets; p++) {
                const baseAngle = (p / numPellets) * Math.PI * 2 + (r % 2) * (Math.PI / numPellets);
                const angleJitter = (Math.random() - 0.5) * (Math.PI / numPellets * 0.7);
                const distJitter = (Math.random() - 0.5) * (this.radius / numRings * 0.85);

                const finalDist = Math.max(100, Math.min(this.radius * 0.95, ringDist + distJitter));
                const finalAngle = baseAngle + angleJitter;

                const roll = Math.random();
                let type = 'small';
                if (roll > 0.96) type = 'large';
                else if (roll > 0.82) type = 'medium';

                this.spawnFood(Math.cos(finalAngle) * finalDist, Math.sin(finalAngle) * finalDist, type, false);
            }
        }

        // Spawn initial moving wisps
        for (let i = 0; i < this.targetWispCount; i++) {
            this.spawnWisp();
        }

        // Spawn initial bots
        this.ensureBotPopulation();
    }

    findSafeSpawn(isPlayer = false) {
        // Beginner-friendly spacing: give human player huge 900px sanctuary, and bots 600px clearance
        const minHeadDist = isPlayer ? 900 : 600;
        const minBodyDist = isPlayer ? 500 : 360;
        const maxAttempts = isPlayer ? 50 : 35;

        for (let attempts = 0; attempts < maxAttempts; attempts++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = (0.15 + Math.random() * 0.68) * this.radius;
            const x = Math.cos(angle) * dist;
            const y = Math.sin(angle) * dist;

            let safe = true;
            for (const s of this.snakes.values()) {
                if (!s.isAlive) continue;
                if (Math.hypot(x - s.x, y - s.y) < minHeadDist) {
                    safe = false;
                    break;
                }
            }

            if (safe && this.snakeGrid) {
                const nearby = this.snakeGrid.queryNearby(x, y, minBodyDist);
                if (nearby.length > 0) {
                    safe = false;
                }
            }

            if (safe) {
                return { x, y, angle: Math.random() * Math.PI * 2 };
            }
        }

        const fallbackAngle = Math.random() * Math.PI * 2;
        const fallbackDist = (0.25 + Math.random() * 0.5) * this.radius;
        return {
            x: Math.cos(fallbackAngle) * fallbackDist,
            y: Math.sin(fallbackAngle) * fallbackDist,
            angle: fallbackAngle
        };
    }

    spawnFood(x, y, type = 'small', trackDelta = true) {
        const id = this.nextFoodId++;
        const color = FOOD_COLORS[Math.floor(Math.random() * FOOD_COLORS.length)];
        let size = 1.4;
        let growth = 0.22;
        let scoreVal = 5;

        if (type === 'medium') {
            size = 2.6;
            growth = 0.65;
            scoreVal = 15;
        } else if (type === 'large') {
            size = 3.8;
            growth = 1.6;
            scoreVal = 45;
        } else if (type === 'death') {
            size = 4.2 + Math.random() * 1.6;
            growth = 3.5;
            scoreVal = 95;
        } else if (type === 'boost') {
            size = 1.1;
            growth = 0.15;
            scoreVal = 3;
        }

        const food = {
            id,
            x: Math.round(x * 10) / 10,
            y: Math.round(y * 10) / 10,
            type,
            size,
            growth,
            scoreVal,
            color,
            createdAt: Date.now()
        };

        this.foods.set(id, food);
        this.foodGrid.insert(id, food.x, food.y, food);

        if (trackDelta) {
            this.newFoods.push([id, food.x, food.y, type, color, size]);
        }

        return food;
    }

    spawnWisp() {
        const id = this.nextWispId++;
        const angle = Math.random() * Math.PI * 2;
        const dist = (0.2 + Math.random() * 0.7) * this.radius;
        const color = ['#ffe600', '#00f0ff', '#ff00aa', '#00ff66', '#ff6600'][id % 5];

        const wisp = {
            id,
            x: Math.cos(angle) * dist,
            y: Math.sin(angle) * dist,
            vx: (Math.random() - 0.5) * 3,
            vy: (Math.random() - 0.5) * 3,
            speed: 3.2 + Math.random() * 1.8,
            color,
            wanderAngle: Math.random() * Math.PI * 2,
            scoreVal: 120,
            growth: 4.5
        };

        this.wisps.set(id, wisp);
        return wisp;
    }

    ensureBotPopulation() {
        let aliveCount = 0;
        for (const s of this.snakes.values()) {
            if (s.isAlive) aliveCount++;
        }
        const needed = this.targetSnakeCount - aliveCount;
        for (let i = 0; i < needed; i++) {
            this.spawnBot();
        }
    }

    spawnBot(specificName = null) {
        const id = `bot_${this.nextSnakeId++}`;
        const name = specificName || BOT_NAMES[Math.floor(Math.random() * BOT_NAMES.length)];
        const skin = SKINS[Math.floor(Math.random() * SKINS.length)];
        const spawn = this.findSafeSpawn();

        // Variety in snake initial lengths: Apex Leviathans, Hunters, Mediums, Agile Scavengers
        const roll = Math.random();
        let initialLength;
        if (roll < 0.10) {
            initialLength = 110 + Math.floor(Math.random() * 60); // Leviathan
        } else if (roll < 0.35) {
            initialLength = 60 + Math.floor(Math.random() * 40);  // Large Hunter
        } else if (roll < 0.70) {
            initialLength = 38 + Math.floor(Math.random() * 20);  // Medium
        } else {
            initialLength = 24 + Math.floor(Math.random() * 12);  // Agile Scavenger
        }

        const snake = this.createSnake(id, name, spawn.x, spawn.y, skin, false, initialLength, spawn.angle);
        snake.decisionTimer = Math.random() * 0.2;
        snake.aggression = 0.12 + Math.random() * 0.35; // Calibrated lower aggression for beginner-friendly gameplay
        snake.serpentineFreq = 1.8 + Math.random() * 1.8;
        snake.serpentineAmp = 0.08 + Math.random() * 0.12;
        snake.serpentinePhase = Math.random() * Math.PI * 2;
        snake.personality = ['hunter', 'forager', 'opportunist', 'cruiser'][Math.floor(Math.random() * 4)];
        this.snakes.set(id, snake);
        return snake;
    }

    createSnake(id, name, x, y, skin, isPlayer = false, initialLength = 32, startAngle = null) {
        const angle = startAngle !== null ? startAngle : Math.random() * Math.PI * 2;
        const segments = [];
        const segmentSpacing = 6;

        for (let i = 0; i < initialLength; i++) {
            segments.push({
                x: Math.round((x - Math.cos(angle) * (i * segmentSpacing)) * 10) / 10,
                y: Math.round((y - Math.sin(angle) * (i * segmentSpacing)) * 10) / 10
            });
        }

        return {
            id,
            name: name.substring(0, 15),
            x,
            y,
            angle,
            targetAngle: angle,
            baseSpeed: isPlayer ? 4.5 : 4.1,
            boostSpeed: (isPlayer ? 4.5 : 4.1) * 1.95,
            speed: isPlayer ? 4.5 : 4.1,
            turnSpeed: 0.088,
            isBoosting: false,
            boostEnergy: 100,
            boostDropTimer: 0,
            length: initialLength,
            width: 16,
            score: initialLength * 10,
            kills: 0,
            skin,
            isPlayer,
            isAlive: true,
            segments,
            segmentSpacing,
            lastInputTime: Date.now()
        };
    }

    addPlayer(socket, name, skinIndex) {
        // Clean up existing snake for this socket if rejoining / respawning
        const oldSnake = this.clients.get(socket);
        if (oldSnake) {
            this.snakes.delete(oldSnake.id);
        }

        const id = `player_${this.nextSnakeId++}`;
        const skin = SKINS[skinIndex] || SKINS[0];
        // Enforce 900px safe spawn sanctuary for player
        const spawn = this.findSafeSpawn(true);

        // Player starts with a generous initial length of 52 for a more empowering, beginner-friendly start
        const snake = this.createSnake(id, name || 'NeonPlayer', spawn.x, spawn.y, skin, true, 52, spawn.angle);
        this.snakes.set(id, snake);
        this.clients.set(socket, snake);

        // Send initial setup to player
        const foodList = [];
        for (const f of this.foods.values()) {
            foodList.push([f.id, f.x, f.y, f.type, f.color, f.size]);
        }

        socket.send({
            type: 'init',
            playerId: id,
            startX: snake.x,
            startY: snake.y,
            startAngle: snake.angle,
            radius: this.radius,
            foods: foodList
        });

        return snake;
    }

    removePlayer(socket) {
        const snake = this.clients.get(socket);
        if (snake) {
            this.clients.delete(socket);
            if (snake.isAlive) {
                this.killSnake(snake, "disconnect", null);
            }
            this.snakes.delete(snake.id);
        }
    }

    handlePlayerInput(socket, input) {
        const snake = this.clients.get(socket);
        if (!snake || !snake.isAlive) return;

        if (typeof input.angle === 'number' && !isNaN(input.angle)) {
            snake.targetAngle = input.angle;
        }
        if (typeof input.isBoosting === 'boolean') {
            snake.isBoosting = input.isBoosting;
        }
        snake.lastInputTime = Date.now();
    }

    startLoop() {
        const TICK_RATE = 30; // 30 ticks per second
        const TICK_INTERVAL = 1000 / TICK_RATE;

        setInterval(() => {
            const now = Date.now();
            const dt = Math.min(0.08, (now - this.lastTickTime) / 1000);
            this.lastTickTime = now;
            this.tickCount++;

            this.update(dt);

            // Broadcast state at 20 Hz (every 1.5 ticks) for optimal bandwidth
            if (this.tickCount % 2 === 0) {
                this.broadcastState();
            }
        }, TICK_INTERVAL);
    }

    update(dt) {
        // 1. Rebuild spatial grids for food and snake bodies
        this.foodGrid.clear();
        for (const food of this.foods.values()) {
            this.foodGrid.insert(food.id, food.x, food.y, food);
        }

        this.snakeGrid.clear();
        for (const snake of this.snakes.values()) {
            if (!snake.isAlive) continue;
            const segs = snake.segments;
            // Insert all segments from index 1 (immediate neck) onward so enemies cannot pass through neck or chest
            for (let i = 1; i < segs.length; i++) {
                const seg = segs[i];
                this.snakeGrid.insert(`${snake.id}_${i}`, seg.x, seg.y, {
                    snakeId: snake.id,
                    segIndex: i,
                    segX: seg.x,
                    segY: seg.y,
                    width: snake.width
                });
            }
        }

        // 2. Update AI Bots
        for (const snake of this.snakes.values()) {
            if (!snake.isPlayer && snake.isAlive) {
                this.updateBotAI(snake, dt);
            }
        }

        // 3. Update Snake Kinematics & Boosting
        for (const snake of this.snakes.values()) {
            if (!snake.isAlive) continue;
            this.updateSnakePhysics(snake, dt);
        }

        // 4. Update Moving Wisps
        this.updateWisps(dt);

        // 5. Check Arena Boundary Collisions
        for (const snake of this.snakes.values()) {
            if (!snake.isAlive) continue;
            const distFromCenter = Math.hypot(snake.x, snake.y);
            if (distFromCenter >= this.radius) {
                this.killSnake(snake, "boundary", null);
            }
        }

        // 6. Check Head-to-Head & Head-to-Body Snake Collisions
        this.checkSnakeCollisions();

        // 7. Check Food & Wisp Consumption
        this.checkConsumption();

        // 8. Maintain ambient food at a measured, non-clustering pace
        this.foodSpawnTimer = (this.foodSpawnTimer || 0) + dt;
        if (this.foodSpawnTimer >= 0.5) {
            this.foodSpawnTimer = 0;
            if (this.foods.size < this.targetFoodCount) {
                const angle = Math.random() * Math.PI * 2;
                const dist = Math.sqrt(Math.random()) * (this.radius * 0.96);
                const roll = Math.random();
                let type = 'small';
                if (roll > 0.95) type = 'large';
                else if (roll > 0.8) type = 'medium';
                this.spawnFood(Math.cos(angle) * dist, Math.sin(angle) * dist, type, true);
            }
        }

        // Clean up stale death or boost pellets older than 45 seconds to prevent food clustering
        this.decayTimer = (this.decayTimer || 0) + dt;
        if (this.decayTimer >= 4.0) {
            this.decayTimer = 0;
            const now = Date.now();
            for (const [id, f] of this.foods.entries()) {
                if ((f.type === 'death' || f.type === 'boost') && (now - f.createdAt > 45000)) {
                    this.foods.delete(id);
                    this.eatenFoodIds.push(id);
                }
            }
        }

        while (this.wisps.size < this.targetWispCount) {
            this.spawnWisp();
        }

        this.ensureBotPopulation();
    }

    updateSnakePhysics(snake, dt) {
        // Boost mechanics
        if (snake.isBoosting && snake.length > 15 && snake.boostEnergy > 3) {
            snake.speed = snake.boostSpeed;
            snake.boostEnergy = Math.max(0, snake.boostEnergy - 32 * dt);
            snake.boostDropTimer += dt;

            // Shed glowing pellets behind tail at a controlled rate
            if (snake.boostDropTimer > 0.16) {
                snake.boostDropTimer = 0;
                snake.length = Math.max(15, snake.length - 0.18);
                const tail = snake.segments[snake.segments.length - 1];
                if (tail && this.foods.size < 1500) {
                    this.spawnFood(
                        tail.x + (Math.random() - 0.5) * 12,
                        tail.y + (Math.random() - 0.5) * 12,
                        'boost',
                        true
                    );
                }
            }
        } else {
            snake.speed = snake.baseSpeed;
            snake.boostEnergy = Math.min(100, snake.boostEnergy + 24 * dt);
            if (snake.boostEnergy < 4) snake.isBoosting = false;
        }

        // Smooth natural angular interpolation (frame-rate independent easing, matching client)
        let diff = snake.targetAngle - snake.angle;
        while (diff < -Math.PI) diff += Math.PI * 2;
        while (diff > Math.PI) diff -= Math.PI * 2;

        const lengthWeight = 1 / (1 + Math.sqrt(Math.max(0, snake.length - 25)) * 0.022);
        const turnRate = (snake.isPlayer ? 2.85 : 2.5) * (snake.isBoosting ? 1.15 : 1.0) * lengthWeight;
        const maxTurn = turnRate * dt;
        const smoothStep = (1 - Math.exp(-turnRate * 1.25 * dt)) * diff;
        snake.angle += Math.max(-maxTurn, Math.min(maxTurn, smoothStep));

        // Advance head
        snake.x += Math.cos(snake.angle) * (snake.speed * 60 * dt);
        snake.y += Math.sin(snake.angle) * (snake.speed * 60 * dt);

        // Update body segments with distance constraints
        if (snake.segments.length > 0) {
            snake.segments[0].x = snake.x;
            snake.segments[0].y = snake.y;

            const targetCount = Math.floor(snake.length);
            while (snake.segments.length < targetCount) {
                const last = snake.segments[snake.segments.length - 1];
                snake.segments.push({ x: last.x, y: last.y });
            }
            while (snake.segments.length > targetCount && snake.segments.length > 10) {
                snake.segments.pop();
            }

            for (let i = 1; i < snake.segments.length; i++) {
                const prev = snake.segments[i - 1];
                const curr = snake.segments[i];

                const dx = prev.x - curr.x;
                const dy = prev.y - curr.y;
                const dist = Math.hypot(dx, dy);

                if (dist > snake.segmentSpacing) {
                    const factor = (dist - snake.segmentSpacing) / dist;
                    curr.x += dx * factor;
                    curr.y += dy * factor;
                }
            }
        }

        // Width scales smoothly with length
        snake.width = Math.min(36, 15 + Math.sqrt(snake.length) * 0.72);
        snake.score = Math.round(snake.length * 10 + snake.kills * 200);
    }

    updateBotAI(bot, dt) {
        bot.serpentinePhase = (bot.serpentinePhase || 0) + dt * (bot.serpentineFreq || 2.2);

        // 1. Arena boundary repulsion
        const distFromCenter = Math.hypot(bot.x, bot.y);
        if (distFromCenter > this.radius * 0.83) {
            bot.targetAngle = Math.atan2(-bot.y, -bot.x);
            bot.isBoosting = false;
            return;
        }

        // 2. Emergency close-range body repulsion to prevent passing closely or inside other snakes
        const dangerRadius = bot.width + 45;
        const nearbyDanger = this.snakeGrid.queryNearby(bot.x, bot.y, dangerRadius);
        for (let i = 0; i < nearbyDanger.length; i++) {
            const item = nearbyDanger[i].data;
            if (item.snakeId === bot.id) continue;
            const dx = bot.x - item.segX;
            const dy = bot.y - item.segY;
            const distSq = dx * dx + dy * dy;
            if (distSq < dangerRadius * dangerRadius && distSq > 0.01) {
                bot.targetAngle = Math.atan2(dy, dx);
                bot.isBoosting = false;
                bot.decisionTimer = 0.16;
                return;
            }
        }

        // 3. Multi-ray forward collision & body avoidance
        const forwardDist = 120;
        const flankDist = 100;
        const flankAngle = 0.72;

        const centerProbeX = bot.x + Math.cos(bot.angle) * forwardDist;
        const centerProbeY = bot.y + Math.sin(bot.angle) * forwardDist;
        const leftProbeX = bot.x + Math.cos(bot.angle - flankAngle) * flankDist;
        const leftProbeY = bot.y + Math.sin(bot.angle - flankAngle) * flankDist;
        const rightProbeX = bot.x + Math.cos(bot.angle + flankAngle) * flankDist;
        const rightProbeY = bot.y + Math.sin(bot.angle + flankAngle) * flankDist;

        const centerThreats = this.snakeGrid.queryNearby(centerProbeX, centerProbeY, 55).filter(t => t.data.snakeId !== bot.id);
        const leftThreats = this.snakeGrid.queryNearby(leftProbeX, leftProbeY, 50).filter(t => t.data.snakeId !== bot.id);
        const rightThreats = this.snakeGrid.queryNearby(rightProbeX, rightProbeY, 50).filter(t => t.data.snakeId !== bot.id);

        if (centerThreats.length > 0) {
            if (leftThreats.length < rightThreats.length) {
                bot.targetAngle = bot.angle - 1.45;
            } else if (rightThreats.length < leftThreats.length) {
                bot.targetAngle = bot.angle + 1.45;
            } else {
                bot.targetAngle = bot.angle + (Math.random() < 0.5 ? -2.2 : 2.2);
            }
            bot.isBoosting = bot.boostEnergy > 30 && Math.random() < 0.6;
            bot.decisionTimer = 0.16;
            return;
        }

        bot.decisionTimer -= dt;
        if (bot.decisionTimer > 0) {
            // Apply subtle organic serpentine slither while cruising
            bot.targetAngle += Math.sin(bot.serpentinePhase) * (bot.serpentineAmp || 0.12) * dt * 2.5;
            return;
        }
        bot.decisionTimer = 0.14 + Math.random() * 0.22;

        // 3. Competitive Rival Cut-Off Tactics (calibrated for fair, beginner-friendly challenge)
        if (bot.aggression > 0.52) {
            let targetPrey = null;
            let minPreyDistSq = 320 * 320;

            for (const other of this.snakes.values()) {
                if (!other.isAlive || other === bot) continue;
                const dx = other.x - bot.x;
                const dy = other.y - bot.y;
                const dSq = dx * dx + dy * dy;

                // Beginners get breathing room: bots focus on each other rather than hunting the human player
                const priorityWeight = other.isPlayer ? 1.6 : 0.85;
                const weightedDistSq = dSq * priorityWeight;

                if (weightedDistSq < minPreyDistSq) {
                    minPreyDistSq = weightedDistSq;
                    targetPrey = other;
                }
            }

            if (targetPrey) {
                // Calculate cut-off intercept point ahead of the opponent
                const interceptLead = 60;
                const targetLeadX = targetPrey.x + Math.cos(targetPrey.angle) * interceptLead;
                const targetLeadY = targetPrey.y + Math.sin(targetPrey.angle) * interceptLead;

                bot.targetAngle = Math.atan2(targetLeadY - bot.y, targetLeadX - bot.x);
                bot.isBoosting = bot.boostEnergy > 55 && Math.random() < 0.35;
                return;
            }
        }

        // 4. Intelligent Food Foraging via Spatial Grid
        const nearbyFoods = this.foodGrid.queryNearby(bot.x, bot.y, 440);
        let nearestFood = null;
        let minFoodDistSq = 440 * 440;

        for (let i = 0; i < nearbyFoods.length; i++) {
            const item = nearbyFoods[i];
            const food = item.data;
            const dx = food.x - bot.x;
            const dy = food.y - bot.y;
            const dSq = dx * dx + dy * dy;
            // Death pellets from destroyed snakes are strongly prioritized
            const weightedDist = food.type === 'death' ? dSq * 0.25 : (food.type === 'large' ? dSq * 0.5 : dSq);

            if (weightedDist < minFoodDistSq) {
                minFoodDistSq = weightedDist;
                nearestFood = food;
            }
        }

        if (nearestFood) {
            bot.targetAngle = Math.atan2(nearestFood.y - bot.y, nearestFood.x - bot.x);
            bot.isBoosting = (nearestFood.type === 'death' || nearestFood.type === 'large') && bot.boostEnergy > 45 && Math.random() < bot.aggression;
        } else {
            // Gentle natural wander
            bot.targetAngle += (Math.random() - 0.5) * 0.45;
            bot.isBoosting = false;
        }

        // Natural serpentine wiggle
        bot.targetAngle += Math.sin(bot.serpentinePhase) * (bot.serpentineAmp || 0.12) * dt * 2.5;
    }

    updateWisps(dt) {
        for (const wisp of this.wisps.values()) {
            // Wander organic motion
            wisp.wanderAngle += (Math.random() - 0.5) * 1.2 * dt;
            let targetSpeed = wisp.speed;

            // Check if any snake head is near (fleeing behavior!)
            let fleeX = 0;
            let fleeY = 0;
            let threatened = false;

            for (const snake of this.snakes.values()) {
                if (!snake.isAlive) continue;
                const dx = wisp.x - snake.x;
                const dy = wisp.y - snake.y;
                const dSq = dx * dx + dy * dy;

                if (dSq < 200 * 200) {
                    const dist = Math.sqrt(dSq);
                    fleeX += (dx / dist) * 4.0;
                    fleeY += (dy / dist) * 4.0;
                    threatened = true;
                }
            }

            if (threatened) {
                wisp.wanderAngle = Math.atan2(fleeY, fleeX);
                targetSpeed = 7.2; // Speed up when chased!
            }

            wisp.vx += Math.cos(wisp.wanderAngle) * targetSpeed * 2.5 * dt;
            wisp.vy += Math.sin(wisp.wanderAngle) * targetSpeed * 2.5 * dt;
            wisp.vx *= 0.94;
            wisp.vy *= 0.94;

            wisp.x += wisp.vx;
            wisp.y += wisp.vy;

            // Bounce gently off boundaries
            const distFromCenter = Math.hypot(wisp.x, wisp.y);
            if (distFromCenter > this.radius * 0.92) {
                const angle = Math.atan2(wisp.y, wisp.x);
                wisp.x = Math.cos(angle) * (this.radius * 0.92);
                wisp.y = Math.sin(angle) * (this.radius * 0.92);
                wisp.wanderAngle = angle + Math.PI;
            }
        }
    }

    checkSnakeCollisions() {
        const snakeList = Array.from(this.snakes.values()).filter(s => s.isAlive);

        // 1. Head-to-Head Collision and Elastic Repulsion
        for (let i = 0; i < snakeList.length; i++) {
            const snakeA = snakeList[i];
            if (!snakeA.isAlive) continue;

            for (let j = i + 1; j < snakeList.length; j++) {
                const snakeB = snakeList[j];
                if (!snakeB.isAlive) continue;

                const dx = snakeA.x - snakeB.x;
                const dy = snakeA.y - snakeB.y;
                const distSq = dx * dx + dy * dy;
                const minHeadDist = (snakeA.width + snakeB.width) * 0.48;

                if (distSq < minHeadDist * minHeadDist) {
                    const dist = Math.max(0.1, Math.sqrt(distSq));
                    const overlap = minHeadDist - dist;
                    const nx = dx / dist;
                    const ny = dy / dist;

                    // Elastic deflection pushes heads apart immediately so they never penetrate
                    snakeA.x += nx * overlap * 0.5;
                    snakeA.y += ny * overlap * 0.5;
                    snakeB.x -= nx * overlap * 0.5;
                    snakeB.y -= ny * overlap * 0.5;

                    // Check dominance ratio
                    const ratio = snakeA.length / Math.max(1, snakeB.length);
                    if (ratio > 1.25) {
                        // Snake A dominates Snake B
                        snakeA.kills++;
                        snakeA.length += 3.5;
                        snakeA.score += 250;
                        this.killSnake(snakeB, "collision", snakeA);
                    } else if (ratio < 0.8) {
                        // Snake B dominates Snake A
                        snakeB.kills++;
                        snakeB.length += 3.5;
                        snakeB.score += 250;
                        this.killSnake(snakeA, "collision", snakeB);
                    } else {
                        // Similar size: both bounce away cleanly
                        snakeA.angle = Math.atan2(ny, nx) + (Math.random() - 0.5) * 0.4;
                        snakeB.angle = Math.atan2(-ny, -nx) + (Math.random() - 0.5) * 0.4;
                        snakeA.targetAngle = snakeA.angle;
                        snakeB.targetAngle = snakeB.angle;
                    }
                }
            }
        }

        // 2. Head-to-Body Collision via Spatial Grid
        for (let i = 0; i < snakeList.length; i++) {
            const snakeA = snakeList[i];
            if (!snakeA.isAlive) continue;

            const headX = snakeA.x;
            const headY = snakeA.y;
            const queryRadius = snakeA.width * 0.9 + 25;

            const nearbySegments = this.snakeGrid.queryNearby(headX, headY, queryRadius);
            for (let k = 0; k < nearbySegments.length; k++) {
                const segInfo = nearbySegments[k].data;
                if (segInfo.snakeId === snakeA.id) continue;

                const snakeB = this.snakes.get(segInfo.snakeId);
                if (!snakeB || !snakeB.isAlive) continue;

                const hitRadius = (snakeA.width + segInfo.width) * 0.45;
                const dx = headX - segInfo.segX;
                const dy = headY - segInfo.segY;

                if (dx * dx + dy * dy < hitRadius * hitRadius) {
                    // Snake A ran head-first into Snake B's body: Snake A dies!
                    snakeB.kills++;
                    snakeB.length += 3.5;
                    snakeB.score += 250;

                    this.killSnake(snakeA, "collision", snakeB);
                    break;
                }
            }
        }
    }

    checkConsumption() {
        for (const snake of this.snakes.values()) {
            if (!snake.isAlive) continue;

            const eatRadius = snake.width * 1.35;
            const eatRadiusSq = eatRadius * eatRadius;

            // 1. Food pellets query nearby
            const nearby = this.foodGrid.queryNearby(snake.x, snake.y, eatRadius + 30);
            for (let i = 0; i < nearby.length; i++) {
                const item = nearby[i];
                const food = item.data;
                if (!this.foods.has(food.id)) continue;

                const dx = snake.x - food.x;
                const dy = snake.y - food.y;

                if (dx * dx + dy * dy < eatRadiusSq) {
                    snake.length += food.growth;
                    snake.score += food.scoreVal;

                    this.foods.delete(food.id);
                    this.eatenFoodIds.push(food.id);
                }
            }

            // 2. Moving Wisps
            for (const [wispId, wisp] of this.wisps.entries()) {
                const dx = snake.x - wisp.x;
                const dy = snake.y - wisp.y;

                if (dx * dx + dy * dy < eatRadiusSq + 100) {
                    snake.length += wisp.growth;
                    snake.score += wisp.scoreVal;
                    this.wisps.delete(wispId);

                    this.killFeed.push({
                        text: `✨ ${snake.name} caught a Neon Wisp! (+${wisp.scoreVal})`,
                        color: wisp.color
                    });
                }
            }
        }
    }

    killSnake(snake, reason, killer) {
        if (!snake.isAlive) return;
        snake.isAlive = false;

        // Disperse body into rich glowing collectible death pellets (bounded count, high value)
        const totalSegments = snake.segments.length;
        const maxDeathPellets = 10;
        const dropSpacing = Math.max(2, Math.floor(totalSegments / maxDeathPellets));
        let dropped = 0;

        for (let i = 0; i < totalSegments && dropped < maxDeathPellets; i += dropSpacing) {
            const seg = snake.segments[i];
            const jitterX = seg.x + (Math.random() - 0.5) * 22;
            const jitterY = seg.y + (Math.random() - 0.5) * 22;
            this.spawnFood(jitterX, jitterY, 'death', true);
            dropped++;
        }

        // Add to kill feed
        const killerName = killer ? killer.name : (reason === 'boundary' ? 'Boundary Barrier' : 'Void');
        this.killFeed.push({
            text: `💥 ${snake.name} was eliminated by ${killerName}`,
            killer: killerName,
            victim: snake.name
        });

        // Notify player client if human
        for (const [socket, playerSnake] of this.clients.entries()) {
            if (playerSnake === snake) {
                socket.send({
                    type: 'dead',
                    reason,
                    killerName,
                    finalScore: snake.score,
                    finalKills: snake.kills
                });
            }
        }

        // If it was a bot, remove from map and schedule respawn
        if (!snake.isPlayer) {
            this.snakes.delete(snake.id);
            setTimeout(() => {
                this.ensureBotPopulation();
            }, 2500);
        }
    }

    getLeaderboard() {
        const list = Array.from(this.snakes.values())
            .filter(s => s.isAlive)
            .sort((a, b) => b.score - a.score);

        return list.slice(0, 10).map((s, idx) => ({
            rank: idx + 1,
            id: s.id,
            name: s.name,
            score: s.score,
            kills: s.kills,
            isPlayer: s.isPlayer
        }));
    }

    broadcastState() {
        const leaderboard = this.getLeaderboard();
        const totalSnakes = Array.from(this.snakes.values()).filter(s => s.isAlive).length;

        // Build compact snake list
        const snakePackets = [];
        for (const s of this.snakes.values()) {
            if (!s.isAlive) continue;

            // Accurate segments for smooth client interpolation without downsampling jitter
            const segs = [];
            for (let i = 0; i < s.segments.length; i++) {
                const seg = s.segments[i];
                segs.push([Math.round(seg.x * 10) / 10, Math.round(seg.y * 10) / 10]);
            }

            snakePackets.push({
                id: s.id,
                name: s.name,
                x: Math.round(s.x * 10) / 10,
                y: Math.round(s.y * 10) / 10,
                angle: Math.round(s.angle * 100) / 100,
                width: Math.round(s.width * 10) / 10,
                length: Math.round(s.length),
                score: s.score,
                kills: s.kills,
                isBoosting: s.isBoosting,
                skin: s.skin,
                isPlayer: s.isPlayer,
                segments: segs
            });
        }

        // Wisps packet
        const wispPackets = [];
        for (const w of this.wisps.values()) {
            wispPackets.push({
                id: w.id,
                x: Math.round(w.x * 10) / 10,
                y: Math.round(w.y * 10) / 10,
                color: w.color
            });
        }

        const eaten = this.eatenFoodIds;
        const added = this.newFoods;
        const feed = this.killFeed;

        // Reset delta buffers
        this.eatenFoodIds = [];
        this.newFoods = [];
        this.killFeed = [];

        // Broadcast to all connected clients
        for (const [socket, playerSnake] of this.clients.entries()) {
            let myRank = 1;
            const sorted = Array.from(this.snakes.values())
                .filter(s => s.isAlive)
                .sort((a, b) => b.score - a.score);

            const idx = sorted.findIndex(s => s.id === playerSnake.id);
            if (idx !== -1) myRank = idx + 1;

            const packet = {
                type: 'state',
                snakes: snakePackets,
                wisps: wispPackets,
                leaderboard,
                totalSnakes,
                myStats: {
                    id: playerSnake.id,
                    score: playerSnake.score,
                    length: Math.round(playerSnake.length),
                    kills: playerSnake.kills,
                    rank: myRank,
                    boostEnergy: Math.round(playerSnake.boostEnergy),
                    isAlive: playerSnake.isAlive
                }
            };

            if (eaten.length > 0) packet.eatenFoods = eaten;
            if (added.length > 0) packet.newFoods = added;
            if (feed.length > 0) packet.killFeed = feed;

            socket.send(packet);
        }
    }
}

module.exports = { ArenaServer };

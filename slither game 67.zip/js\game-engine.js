/**
 * NEON SLITHER - Core Arena Game Engine
 * Features:
 * - Real-Time Server-Authoritative Multiplayer over WebSockets with Client-Side Prediction
 * - Smooth Entity Interpolation for Remote Snakes (zero jitter)
 * - Offline / Solo Fallback Mode with intelligent bot combatants
 * - Special Moving High-Value Pellets ("Neon Wisps") with reactive evasion
 * - Fluid 360-degree analog continuous kinematics
 * - Rounded overlapping vertebrae segments with neon depth and rim lighting
 * - Animated expressive eyes with pupil steering tracking and boost dilation
 * - Golden neon crown over the #1 Leaderboard player
 * - Minimap Radar HUD (arena boundary, player beacon, #1 leader, enemy dots)
 * - Screen shake, particle explosions, floating text notifications
 * - Graphics quality scaling (High / Medium / Low)
 */

import { NetworkManager } from './network.js';

// ============================================================================
// SpatialGrid — uniform-cell hash grid for O(1) average broad-phase queries
// ============================================================================
// Stores circular objects (x, y, r, data) in cells. Query returns all objects
// whose bounding box overlaps a given AABB.  Cell size is tuned to ~2× the
// maximum snake half-width so most segment pairs are skipped without any math.
// ============================================================================
class SpatialGrid {
    constructor(cellSize = 80) {
        this.cellSize = cellSize;
        this.cells = new Map(); // key -> [{x,y,r,data}]
    }

    _key(cx, cy) { return (cx & 0xffff) | ((cy & 0xffff) << 16); }

    clear() { this.cells.clear(); }

    insert(x, y, r, data) {
        const cs = this.cellSize;
        const x0 = Math.floor((x - r) / cs);
        const x1 = Math.floor((x + r) / cs);
        const y0 = Math.floor((y - r) / cs);
        const y1 = Math.floor((y + r) / cs);
        for (let cx = x0; cx <= x1; cx++) {
            for (let cy = y0; cy <= y1; cy++) {
                const k = this._key(cx, cy);
                let cell = this.cells.get(k);
                if (!cell) { cell = []; this.cells.set(k, cell); }
                cell.push({ x, y, r, data });
            }
        }
    }

    // Returns all entries whose circle overlaps the query circle (qx,qy,qr)
    query(qx, qy, qr) {
        const cs = this.cellSize;
        const x0 = Math.floor((qx - qr) / cs);
        const x1 = Math.floor((qx + qr) / cs);
        const y0 = Math.floor((qy - qr) / cs);
        const y1 = Math.floor((qy + qr) / cs);
        const seen = new Set();
        const out = [];
        for (let cx = x0; cx <= x1; cx++) {
            for (let cy = y0; cy <= y1; cy++) {
                const cell = this.cells.get(this._key(cx, cy));
                if (!cell) continue;
                for (const e of cell) {
                    if (seen.has(e)) continue;
                    seen.add(e);
                    const dx = e.x - qx, dy = e.y - qy;
                    const rSum = e.r + qr;
                    if (dx * dx + dy * dy <= rSum * rSum) out.push(e);
                }
            }
        }
        return out;
    }
}


export class Snake {
    constructor(id, name, x, y, options = {}) {
        this.id = id;
        this.name = name || 'Anonymous';
        this.x = x;
        this.y = y;
        this.targetX = x;
        this.targetY = y;
        this.angle = options.angle !== undefined ? options.angle : Math.random() * Math.PI * 2;
        this.targetAngle = this.angle;
        this.isAlive = true;
        this.isPlayer = options.isPlayer || false;
        this.isBot = options.isBot || false;

        // Kinematics
        this.baseSpeed = options.isPlayer ? 4.5 : 4.1;
        this.boostSpeed = this.baseSpeed * 1.95;
        // currentSpeed is what actually drives movement - smoothly lerps to target
        this.speed = this.baseSpeed;
        this.currentSpeed = this.baseSpeed;
        this.baseTurnSpeed = options.isPlayer ? 2.85 : 2.5; // Natural, slightly slower Slither-style turning
        this.turnSpeedMultiplier = 1.0;
        this.isBoosting = false;
        this.boostEnergy = 100;
        this.width = 16;
        this.length = options.initialLength || 32;

        // Metrics
        this.score = Math.round(this.length * 10);
        this.kills = 0;
        this.foodEaten = 0;
        this.survivalTime = 0;
        this.distanceToBorder = 0;
        this.isLeader = false;

        // Neon Skin Palette
        this.skin = options.skin || {
            primary: '#00f0ff',
            secondary: '#0066ff',
            glow: '#00f0ff'
        };

        // Segments array: [{ x, y }]
        this.segments = [];
        this.segmentSpacing = 6;
        for (let i = 0; i < this.length; i++) {
            this.segments.push({
                x: this.x - Math.cos(this.angle) * (i * this.segmentSpacing),
                y: this.y - Math.sin(this.angle) * (i * this.segmentSpacing)
            });
        }

        this.boostDropTimer = 0;
    }

    update(dt, game) {
        // Record head position BEFORE this frame's movement — used by swept collision
        this.prevX = this.x;
        this.prevY = this.y;
        if (!this.isAlive) return;

        this.survivalTime += dt;

        // ---- Boost mechanic ----
        const canBoost = this.isBoosting && this.length > 15 && this.boostEnergy > 3;
        if (canBoost) {
            this.boostEnergy = Math.max(0, this.boostEnergy - 32 * dt);
            this.boostDropTimer += dt;

            if (this.boostDropTimer > 0.08) {
                this.boostDropTimer = 0;
                this.length = Math.max(15, this.length - 0.18);
                const tail = this.segments[this.segments.length - 1];
                if (tail && !game.isMultiplayer) {
                    game.spawnFood(
                        tail.x + (Math.random() - 0.5) * 12,
                        tail.y + (Math.random() - 0.5) * 12,
                        'boost'
                    );
                }
            }

            if (Math.random() < 0.6 && game.graphicsQuality !== 'low') {
                const tail = this.segments[this.segments.length - 1] || this;
                game.spawnBoostParticle(tail.x, tail.y, this.skin.glow);
            }
        } else {
            if (this.isBoosting && this.boostEnergy < 4) this.isBoosting = false;
            this.boostEnergy = Math.min(100, this.boostEnergy + 24 * dt);
        }

        // ---- Dynamic width (must be updated before sub-steps so radii are current) ----
        this.width = Math.min(36, 15 + Math.sqrt(this.length) * 0.72);

        // ---- Smooth speed ramp ----
        const targetSpeed = canBoost ? this.boostSpeed : this.baseSpeed;
        const speedBlend = canBoost
            ? 1 - Math.exp(-6.0 * dt)
            : 1 - Math.exp(-4.5 * dt);
        this.currentSpeed = this.currentSpeed + (targetSpeed - this.currentSpeed) * speedBlend;
        this.speed = this.currentSpeed;

        // ---- Smooth angular interpolation (frame-rate independent) ----
        let diff = this.targetAngle - this.angle;
        while (diff < -Math.PI) diff += Math.PI * 2;
        while (diff > Math.PI) diff -= Math.PI * 2;
        const lengthWeight = 1 / (1 + Math.sqrt(Math.max(0, this.length - 25)) * 0.022);
        const turnRate = this.baseTurnSpeed * (this.turnSpeedMultiplier || 1.0) * (canBoost ? 1.15 : 1.0) * lengthWeight;
        const maxTurn = turnRate * dt;
        const smoothStep = (1 - Math.exp(-turnRate * 1.25 * dt)) * diff;
        this.angle += Math.max(-maxTurn, Math.min(maxTurn, smoothStep));

        // ---- Sub-step integration — prevents tunnelling at high speed ----
        // Move the head in micro-steps of at most (halfWidth) pixels so that
        // a swept capsule test at any one step can never skip over a body segment.
        // The segment chain is re-pulled after every sub-step so body positions
        // are always geometrically consistent with the head position.
        const moveTotal = this.currentSpeed * 60 * dt;
        const halfWidth = this.width * 0.5;
        // Cap at 8 sub-steps — almost always 1–2, only 6–8 at max boost low-FPS
        const steps = Math.min(8, Math.ceil(moveTotal / Math.max(halfWidth, 3)));
        const stepDist = moveTotal / steps;
        const cosA = Math.cos(this.angle);
        const sinA = Math.sin(this.angle);

        // Grow / shrink segment array once before the sub-step loop
        const targetCount = Math.max(10, Math.floor(this.length));
        while (this.segments.length < targetCount) {
            const last = this.segments[this.segments.length - 1];
            this.segments.push({ x: last.x, y: last.y });
        }
        while (this.segments.length > targetCount && this.segments.length > 10) {
            this.segments.pop();
        }

        for (let si = 0; si < steps; si++) {
            this.x += cosA * stepDist;
            this.y += sinA * stepDist;

            // Re-pull the full segment chain after each micro-step
            // so the body always trails the head in physically correct positions.
            if (this.segments.length > 0) {
                this.segments[0].x = this.x;
                this.segments[0].y = this.y;
                for (let i = 1; i < this.segments.length; i++) {
                    const prev = this.segments[i - 1];
                    const curr = this.segments[i];
                    const dx = prev.x - curr.x;
                    const dy = prev.y - curr.y;
                    const dist2 = dx * dx + dy * dy;
                    if (dist2 > this.segmentSpacing * this.segmentSpacing) {
                        const dist = Math.sqrt(dist2);
                        const factor = (dist - this.segmentSpacing) / dist;
                        curr.x += dx * factor;
                        curr.y += dy * factor;
                    }
                }
            }
        }

        // Distance to world border
        const distFromCenter = Math.hypot(this.x, this.y);
        this.distanceToBorder = Math.max(0, game.radius - distFromCenter);

        // Border collision in local mode
        if (!game.isMultiplayer && distFromCenter >= game.radius) {
            this.die(game, 'boundary');
            return;
        }

        this.score = Math.round(this.length * 10 + this.kills * 200);
    }

    updateRemote(dt) {
        // Track previous head position for swept collision
        this.prevX = this.x;
        this.prevY = this.y;
        if (!this.isAlive) return;

        // Smooth angle rotation towards server target angle
        let diff = this.targetAngle - this.angle;
        while (diff < -Math.PI) diff += Math.PI * 2;
        while (diff > Math.PI) diff -= Math.PI * 2;

        const lengthWeight = 1 / (1 + Math.sqrt(Math.max(0, this.length - 25)) * 0.022);
        const turnRate = 2.85 * (this.isBoosting ? 1.15 : 1.0) * lengthWeight;
        const maxTurn = turnRate * dt;
        const smoothStep = (1 - Math.exp(-turnRate * 1.25 * dt)) * diff;
        this.angle += Math.max(-maxTurn, Math.min(maxTurn, smoothStep));

        // Smoothly ramp speed for remote snakes too (prevents teleport during boost)
        if (this.currentSpeed === undefined) this.currentSpeed = this.speed;
        const remoteTarget = this.isBoosting ? this.boostSpeed : this.baseSpeed;
        const remoteBlend = this.isBoosting ? 1 - Math.exp(-6.0 * dt) : 1 - Math.exp(-4.5 * dt);
        this.currentSpeed = this.currentSpeed + (remoteTarget - this.currentSpeed) * remoteBlend;
        this.speed = this.currentSpeed;

        // Advance head smoothly via client dead reckoning
        const moveDist = this.currentSpeed * 60 * dt;
        this.x += Math.cos(this.angle) * moveDist;
        this.y += Math.sin(this.angle) * moveDist;

        // Follow body segments
        if (this.segments.length > 0) {
            this.segments[0].x = this.x;
            this.segments[0].y = this.y;

            for (let i = 1; i < this.segments.length; i++) {
                const prev = this.segments[i - 1];
                const curr = this.segments[i];
                const dx = prev.x - curr.x;
                const dy = prev.y - curr.y;
                const dist = Math.hypot(dx, dy);

                if (dist > this.segmentSpacing) {
                    const factor = (dist - this.segmentSpacing) / dist;
                    curr.x += dx * factor;
                    curr.y += dy * factor;
                }
            }
        }
    }

    interpolate(targetData, lerpFactor = 0.32) {
        if (!targetData) return;

        this.targetX = targetData.x;
        this.targetY = targetData.y;
        this.targetAngle = targetData.angle;

        // Soft position adjustment towards server state
        const dx = this.targetX - this.x;
        const dy = this.targetY - this.y;
        const dist = Math.hypot(dx, dy);
        if (dist > 120) {
            this.x = this.targetX;
            this.y = this.targetY;
            if (targetData.segments && Array.isArray(targetData.segments)) {
                for (let i = 0; i < targetData.segments.length && i < this.segments.length; i++) {
                    const s = targetData.segments[i];
                    this.segments[i].x = Array.isArray(s) ? s[0] : s.x;
                    this.segments[i].y = Array.isArray(s) ? s[1] : s.y;
                }
            }
        } else {
            this.x += dx * lerpFactor;
            this.y += dy * lerpFactor;
        }

        // Angle lerp
        let diff = targetData.angle - this.angle;
        while (diff < -Math.PI) diff += Math.PI * 2;
        while (diff > Math.PI) diff -= Math.PI * 2;
        this.angle += diff * lerpFactor;

        this.width = targetData.width || this.width;
        this.length = targetData.length || this.length;
        this.score = targetData.score || this.score;
        this.kills = targetData.kills || this.kills;
        // Only update the isBoosting flag; actual speed ramping is handled by updateRemote()
        // to avoid instant speed jumps when server packets arrive
        this.isBoosting = targetData.isBoosting !== undefined ? targetData.isBoosting : this.isBoosting;
        if (this.currentSpeed === undefined) this.currentSpeed = this.speed;
        this.name = targetData.name || this.name;
        this.skin = targetData.skin || this.skin;

        if (targetData.segments && Array.isArray(targetData.segments)) {
            const serverSegs = targetData.segments;
            while (this.segments.length < serverSegs.length) {
                this.segments.push({ x: this.x, y: this.y });
            }
            while (this.segments.length > serverSegs.length && this.segments.length > 5) {
                this.segments.pop();
            }

            for (let i = 0; i < serverSegs.length && i < this.segments.length; i++) {
                const s = serverSegs[i];
                const segX = Array.isArray(s) ? s[0] : s.x;
                const segY = Array.isArray(s) ? s[1] : s.y;
                this.segments[i].x += (segX - this.segments[i].x) * lerpFactor;
                this.segments[i].y += (segY - this.segments[i].y) * lerpFactor;
            }
        }
    }

    die(game, reason = "collision", killer = null) {
        if (!this.isAlive) return;
        this.isAlive = false;

        // Disperse body into rich collectible glowing death pellets
        const dropSpacing = 2;
        for (let i = 0; i < this.segments.length; i += dropSpacing) {
            const seg = this.segments[i];
            const jitterX = seg.x + (Math.random() - 0.5) * 24;
            const jitterY = seg.y + (Math.random() - 0.5) * 24;
            game.spawnFood(jitterX, jitterY, 'death');
        }

        // Explosive death shockwave particles
        game.spawnExplosion(this.x, this.y, this.skin.glow, game.graphicsQuality === 'low' ? 14 : 32);

        if (this.isPlayer) {
            game.triggerScreenShake(14, 0.45);
        }

        if (this.onDeath) this.onDeath(reason, killer);
    }

    grow(amount = 1.0, scoreBonus = 10) {
        this.length += amount;
        this.foodEaten += 1;
        this.score += scoreBonus;
    }
}

export class BotSnake extends Snake {
    constructor(id, name, x, y, options = {}) {
        super(id, name, x, y, Object.assign({}, options, { isBot: true }));
        this.decisionTimer = Math.random() * 0.2;
        this.aggression = 0.12 + Math.random() * 0.35; // Calibrated for beginner-friendly gameplay
        this.serpentineFreq = 1.8 + Math.random() * 1.8;
        this.serpentineAmp = 0.08 + Math.random() * 0.12;
        this.serpentinePhase = Math.random() * Math.PI * 2;
    }

    updateAI(dt, game) {
        this.serpentinePhase += dt * this.serpentineFreq;
        this.decisionTimer -= dt;
        if (this.decisionTimer <= 0) {
            this.decisionTimer = 0.14 + Math.random() * 0.22;
            this.makeDecision(game);
        }

        this.update(dt, game);
    }

    makeDecision(game) {
        // 1. Avoid dangerous boundaries
        const distFromCenter = Math.hypot(this.x, this.y);
        if (distFromCenter > game.radius * 0.85) {
            this.targetAngle = Math.atan2(-this.y, -this.x);
            this.isBoosting = false;
            return;
        }

        // 2. Threat repulsion from enemy snake bodies
        const scanDist = 190;
        let repelX = 0;
        let repelY = 0;
        let threatFound = false;

        const checkStep = game.graphicsQuality === 'low' ? 5 : 3;
        for (const s of game.snakes) {
            if (!s.isAlive || s === this) continue;

            for (let i = 1; i < s.segments.length; i += checkStep) {
                const seg = s.segments[i];
                const dx = this.x - seg.x;
                const dy = this.y - seg.y;
                const distSq = dx * dx + dy * dy;

                if (distSq < scanDist * scanDist && distSq > 0) {
                    const dist = Math.sqrt(distSq);
                    const force = (scanDist - dist) / scanDist;
                    repelX += (dx / dist) * force * 3.2;
                    repelY += (dy / dist) * force * 3.2;
                    threatFound = true;
                }
            }
        }

        if (threatFound) {
            this.targetAngle = Math.atan2(repelY, repelX);
            this.isBoosting = Math.random() < 0.35 && this.boostEnergy > 30;
            return;
        }

        // 3. Hunt smaller snakes if aggressive
        if (this.aggression > 0.6 && Math.random() < 0.35) {
            let preyTarget = null;
            let minPreyDistSq = 360 * 360;

            for (const s of game.snakes) {
                if (!s.isAlive || s === this || s.length >= this.length) continue;
                const dx = s.x - this.x;
                const dy = s.y - this.y;
                const dSq = dx * dx + dy * dy;
                if (dSq < minPreyDistSq) {
                    minPreyDistSq = dSq;
                    preyTarget = s;
                }
            }

            if (preyTarget) {
                const leadDist = 55;
                const targetX = preyTarget.x + Math.cos(preyTarget.angle) * leadDist;
                const targetY = preyTarget.y + Math.sin(preyTarget.angle) * leadDist;
                this.targetAngle = Math.atan2(targetY - this.y, targetX - this.x);
                this.isBoosting = this.boostEnergy > 35;
                return;
            }
        }

        // 4. Forage nearby food
        let nearestFood = null;
        let minDistSq = 420 * 420;

        const foodStep = game.graphicsQuality === 'low' ? 3 : 2;
        for (let i = 0; i < game.foods.length; i += foodStep) {
            const food = game.foods[i];
            const dx = food.x - this.x;
            const dy = food.y - this.y;
            const dSq = dx * dx + dy * dy;

            const weightedDist = food.type === 'death' ? dSq * 0.35 : dSq;
            if (weightedDist < minDistSq) {
                minDistSq = weightedDist;
                nearestFood = food;
            }
        }

        if (nearestFood) {
            this.targetAngle = Math.atan2(nearestFood.y - this.y, nearestFood.x - this.x);
            this.isBoosting = nearestFood.type === 'death' && Math.random() < this.aggression;
        } else {
            // Gentle random wander
            this.targetAngle += (Math.random() - 0.5) * 0.6;
            this.isBoosting = false;
        }
    }
}

export class GameEngine {
    constructor(canvas) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d', { alpha: false });
        this.radius = 4500;
        this.snakes = [];
        this.snakesMap = new Map(); // id -> Snake
        this.foods = [];
        this.foodsMap = new Map(); // id -> Food
        this.wisps = [];
        this.particles = [];
        this.floatingTexts = [];
        this.player = null;

        // Multiplayer Network
        this.network = new NetworkManager();
        this.isMultiplayer = false;
        this.multiplayerConnected = false;
        this.topLeaderboard = [];
        this.totalPlayers = 1;

        // Camera
        this.camera = {
            x: 0,
            y: 0,
            zoom: 1.0,
            targetZoom: 1.0
        };

        // Screen shake
        this.shakeIntensity = 0;
        this.shakeTimer = 0;

        // Input
        this.mouse = { x: 0, y: 0, isDown: false };
        this.keyboardHeading = null;
        this.keys = {};
        this.turnSensitivity = 1.0;

        // Graphics quality: 'high', 'med', 'low'
        this.graphicsQuality = 'high';

        // Engine lifecycle & states
        this.lastTime = performance.now();
        this.isRunning = false;
        this.isPaused = false;
        this.fps = 60;
        this.frameCount = 0;

        // 8 Original Vibrant Skins
        this.skins = [
            { id: 'neon-blue', name: 'Neon Blue', primary: '#0284c7', secondary: '#0369a1', glow: '#0284c7' },
            { id: 'cyber-purple', name: 'Cyber Purple', primary: '#8b5cf6', secondary: '#7c3aed', glow: '#8b5cf6' },
            { id: 'electric-green', name: 'Electric Green', primary: '#10b981', secondary: '#059669', glow: '#10b981' },
            { id: 'hot-pink', name: 'Hot Pink', primary: '#ec4899', secondary: '#db2777', glow: '#ec4899' },
            { id: 'plasma-orange', name: 'Plasma Orange', primary: '#f97316', secondary: '#ea580c', glow: '#f97316' },
            { id: 'laser-red', name: 'Laser Red', primary: '#ef4444', secondary: '#dc2626', glow: '#ef4444' },
            { id: 'ice-cyan', name: 'Ice Cyan', primary: '#06b6d4', secondary: '#0891b2', glow: '#06b6d4' },
            { id: 'toxic-lime', name: 'Toxic Lime', primary: '#84cc16', secondary: '#65a30d', glow: '#84cc16' }
        ];

        this.selectedSkinIndex = 0;
        this.setupCanvas();
        this.bindInput();
        this.setupNetworkCallbacks();
    }

    setupCanvas() {
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        this.width = window.innerWidth;
        this.height = window.innerHeight;
        this.canvas.width = this.width * dpr;
        this.canvas.height = this.height * dpr;
        this.ctx.resetTransform();
        this.ctx.scale(dpr, dpr);
    }

    bindInput() {
        window.addEventListener('resize', () => this.setupCanvas());

        // Mouse Steering
        window.addEventListener('mousemove', (e) => {
            this.mouse.x = e.clientX;
            this.mouse.y = e.clientY;
            this.updatePlayerSteering();
        });

        window.addEventListener('mousedown', (e) => {
            if (e.button === 0 || e.button === 2) {
                this.mouse.isDown = true;
                if (this.player) this.setPlayerBoosting(true);
            }
        });

        window.addEventListener('mouseup', (e) => {
            this.mouse.isDown = false;
            if (this.player && !this.keys['Space'] && !this.keys['ShiftLeft'] && !this.keys['ShiftRight']) {
                this.setPlayerBoosting(false);
            }
        });

        window.addEventListener('contextmenu', (e) => e.preventDefault());

        // Keyboard Controls (WASD, Arrows, Space, Shift)
        window.addEventListener('keydown', (e) => {
            this.keys[e.code] = true;

            if (e.code === 'Space' || e.code === 'ShiftLeft' || e.code === 'ShiftRight') {
                if (this.player) this.setPlayerBoosting(true);
            }

            this.updateKeyboardHeading();
        });

        window.addEventListener('keyup', (e) => {
            this.keys[e.code] = false;

            if ((e.code === 'Space' || e.code === 'ShiftLeft' || e.code === 'ShiftRight') && !this.mouse.isDown) {
                if (this.player) this.setPlayerBoosting(false);
            }

            this.updateKeyboardHeading();
        });

        // Touch Steering for Mobile
        this.canvas.addEventListener('touchstart', (e) => {
            if (e.touches.length > 0) {
                const touch = e.touches[0];
                this.mouse.x = touch.clientX;
                this.mouse.y = touch.clientY;
                this.updatePlayerSteering();
            }
            if (e.touches.length > 1) {
                if (this.player) this.setPlayerBoosting(true);
            }
        }, { passive: false });

        this.canvas.addEventListener('touchmove', (e) => {
            if (e.touches.length > 0) {
                const touch = e.touches[0];
                this.mouse.x = touch.clientX;
                this.mouse.y = touch.clientY;
                this.updatePlayerSteering();
            }
            e.preventDefault();
        }, { passive: false });

        this.canvas.addEventListener('touchend', (e) => {
            if (e.touches.length <= 1 && !this.mouse.isDown) {
                if (this.player && !this.keys['Space']) this.setPlayerBoosting(false);
            }
        }, { passive: false });
    }

    updateKeyboardHeading() {
        let x = 0;
        let y = 0;

        if (this.keys['KeyW'] || this.keys['ArrowUp']) y -= 1;
        if (this.keys['KeyS'] || this.keys['ArrowDown']) y += 1;
        if (this.keys['KeyA'] || this.keys['ArrowLeft']) x -= 1;
        if (this.keys['KeyD'] || this.keys['ArrowRight']) x += 1;

        if (x !== 0 || y !== 0) {
            this.keyboardHeading = Math.atan2(y, x);
            if (this.player && this.player.isAlive) {
                this.player.targetAngle = this.keyboardHeading;
                if (this.isMultiplayer) {
                    this.network.sendInput(this.player.targetAngle, this.player.isBoosting);
                }
            }
        } else {
            this.keyboardHeading = null;
        }
    }

    updatePlayerSteering() {
        if (!this.player || !this.player.isAlive || this.isPaused) return;

        if (this.keyboardHeading !== null) {
            this.player.targetAngle = this.keyboardHeading;
            if (this.isMultiplayer) {
                this.network.sendInput(this.player.targetAngle, this.player.isBoosting);
            }
            return;
        }

        // Exact screen position of player head accounting for camera position and zoom
        const zoom = this.camera.zoom || 1.0;
        const headScreenX = (this.width / 2) + (this.player.x - this.camera.x) * zoom;
        const headScreenY = (this.height / 2) + (this.player.y - this.camera.y) * zoom;

        const dx = this.mouse.x - headScreenX;
        const dy = this.mouse.y - headScreenY;
        const dist = Math.hypot(dx, dy);

        // Comfortable deadzone to eliminate micro-jitter when cursor hovers near the head
        const deadzone = 22 * zoom;
        if (dist > deadzone) {
            this.player.targetAngle = Math.atan2(dy, dx);
            if (this.isMultiplayer) {
                this.network.sendInput(this.player.targetAngle, this.player.isBoosting);
            }
        }
    }

    setPlayerBoosting(boosting) {
        if (!this.player) return;
        const prev = this.player.isBoosting;
        this.player.isBoosting = boosting;
        if (this.isMultiplayer) {
            this.network.sendInput(this.player.targetAngle, this.player.isBoosting, true);
        }
        if (boosting !== prev && this.onBoostChange) {
            this.onBoostChange(boosting);
        }
    }

    setJoystickInput(dx, dy, isBoosting = false) {
        if (!this.player || !this.player.isAlive || this.isPaused) return;

        const len = Math.hypot(dx, dy);
        if (len > 0.15) {
            this.player.targetAngle = Math.atan2(dy, dx);
        }
        if (isBoosting !== undefined) {
            const prev = this.player.isBoosting;
            this.player.isBoosting = isBoosting;
            if (isBoosting !== prev && this.onBoostChange) {
                this.onBoostChange(isBoosting);
            }
        }
        if (this.isMultiplayer) {
            this.network.sendInput(this.player.targetAngle, this.player.isBoosting);
        }
    }

    triggerScreenShake(intensity = 8, duration = 0.3) {
        if (this.graphicsQuality === 'low') return;
        this.shakeIntensity = intensity;
        this.shakeTimer = duration;
    }

    spawnFloatingText(text, x, y, color = '#ccff00') {
        this.floatingTexts.push({
            text,
            x,
            y,
            color,
            life: 0.85,
            maxLife: 0.85,
            vy: -44
        });
    }

    setupNetworkCallbacks() {
        this.network.onInit = (data) => {
            this.isMultiplayer = true;
            this.multiplayerConnected = true;
            this.radius = data.radius || this.radius;

            if (this.offlineFallbackTimer) {
                clearTimeout(this.offlineFallbackTimer);
                this.offlineFallbackTimer = null;
            }

            // Remove any leftover offline snakes so they never linger as ghosts
            for (let i = this.snakes.length - 1; i >= 0; i--) {
                if (this.snakes[i] !== this.player) {
                    this.snakesMap.delete(this.snakes[i].id);
                    this.snakes.splice(i, 1);
                }
            }

            if (this.player && data.playerId) {
                this.snakesMap.delete(this.player.id);
                this.player.id = data.playerId;
                this.snakesMap.set(this.player.id, this.player);

                if (typeof data.startX === 'number' && typeof data.startY === 'number') {
                    this.player.x = data.startX;
                    this.player.y = data.startY;
                    this.player.angle = (typeof data.startAngle === 'number') ? data.startAngle : 0;
                    this.player.targetAngle = this.player.angle;

                    // Align all segments immediately behind the head to prevent stretched-line artifacts
                    for (let i = 0; i < this.player.segments.length; i++) {
                        this.player.segments[i].x = data.startX - Math.cos(this.player.angle) * (i * this.player.segmentSpacing);
                        this.player.segments[i].y = data.startY - Math.sin(this.player.angle) * (i * this.player.segmentSpacing);
                    }

                    this.camera.x = data.startX;
                    this.camera.y = data.startY;
                }
            }

            // Load initial foods from server
            if (data.foods) {
                this.foods = [];
                this.foodsMap.clear();
                for (const f of data.foods) {
                    const [id, x, y, type, color, size] = f;
                    const foodObj = {
                        id,
                        x,
                        y,
                        type,
                        color,
                        size: size || 1.4,
                        pulseOffset: Math.random() * Math.PI * 2
                    };
                    this.foods.push(foodObj);
                    this.foodsMap.set(id, foodObj);
                }
            }
        };

        this.network.onState = (packet) => {
            this.topLeaderboard = packet.leaderboard || [];
            this.totalPlayers = packet.totalSnakes || 1;

            // Update myStats if alive
            if (packet.myStats && this.player) {
                this.player.score = packet.myStats.score;
                this.player.kills = packet.myStats.kills;
                this.player.boostEnergy = packet.myStats.boostEnergy;
                this.player.rank = packet.myStats.rank;
            }

            // Sync snakes
            const serverSnakes = packet.snakes || [];
            const activeIds = new Set();

            for (const sData of serverSnakes) {
                activeIds.add(sData.id);

                if (this.player && sData.id === this.network.playerId) {
                    // Local player reconciliation: smooth drift compensation without rubberband jitter
                    const dx = sData.x - this.player.x;
                    const dy = sData.y - this.player.y;
                    const drift = Math.hypot(dx, dy);

                    if (drift > 160) {
                        // Severe desync / warp: align head and segments cleanly
                        this.player.x = sData.x;
                        this.player.y = sData.y;
                        for (let i = 0; i < this.player.segments.length; i++) {
                            this.player.segments[i].x = sData.x - Math.cos(this.player.angle) * (i * this.player.segmentSpacing);
                            this.player.segments[i].y = sData.y - Math.sin(this.player.angle) * (i * this.player.segmentSpacing);
                        }
                    } else if (drift > 65) {
                        // Soft smooth damping nudge only when significant drift occurs (avoids latency stutter)
                        this.player.x += dx * 0.04;
                        this.player.y += dy * 0.04;
                    }

                    this.player.length = sData.length;
                    this.player.score = sData.score;
                    this.player.kills = sData.kills;
                    this.player.isLeader = (this.topLeaderboard[0] && this.topLeaderboard[0].id === sData.id);
                    continue;
                }

                let snake = this.snakesMap.get(sData.id);
                if (!snake) {
                    snake = new Snake(sData.id, sData.name, sData.x, sData.y, {
                        skin: sData.skin,
                        initialLength: sData.length,
                        isPlayer: false
                    });
                    this.snakes.push(snake);
                    this.snakesMap.set(sData.id, snake);
                }

                snake.interpolate(sData, 0.32);
                snake.isLeader = (this.topLeaderboard[0] && this.topLeaderboard[0].id === sData.id);
            }

            // Remove disconnected snakes
            for (let i = this.snakes.length - 1; i >= 0; i--) {
                const s = this.snakes[i];
                if (s !== this.player && !activeIds.has(s.id)) {
                    this.snakesMap.delete(s.id);
                    this.snakes.splice(i, 1);
                }
            }

            // Sync moving wisps
            if (packet.wisps) {
                this.wisps = packet.wisps;
            }

            // Sync eaten food delta
            if (packet.eatenFoods) {
                for (const eid of packet.eatenFoods) {
                    const f = this.foodsMap.get(eid);
                    if (f) {
                        this.foodsMap.delete(eid);
                        const idx = this.foods.indexOf(f);
                        if (idx !== -1) this.foods.splice(idx, 1);
                    }
                }
            }

            // Sync added food delta
            if (packet.newFoods) {
                for (const f of packet.newFoods) {
                    const [id, x, y, type, color, size] = f;
                    if (!this.foodsMap.has(id)) {
                        const foodObj = {
                            id,
                            x,
                            y,
                            type,
                            color,
                            size: size || 1.4,
                            pulseOffset: Math.random() * Math.PI * 2
                        };
                        this.foods.push(foodObj);
                        this.foodsMap.set(id, foodObj);
                    }
                }
            }

            // Kill feed notifications
            if (packet.killFeed && packet.killFeed.length > 0) {
                for (const feed of packet.killFeed) {
                    if (this.onKillFeed) this.onKillFeed(feed);
                }
            }
        };

        this.network.onDead = (data) => {
            if (this.player && this.player.isAlive) {
                this.player.isAlive = false;
                this.spawnExplosion(this.player.x, this.player.y, this.player.skin.glow, 36);
                this.triggerScreenShake(14, 0.5);
                if (this.onPlayerDeath) {
                    this.onPlayerDeath(this.player, data.reason || 'collision', data.killerName);
                }
            }
        };

        this.network.onDisconnect = () => {
            if (this.isMultiplayer) {
                console.warn("[i] Disconnected from multiplayer server. Seamlessly falling back to offline arena mode.");
                this.isMultiplayer = false;
                this.multiplayerConnected = false;
                // Transition gracefully to offline bots
                if (this.snakes.length < 10) {
                    this.spawnOfflineBots(18);
                }
            }
        };
    }

    startNewGame(playerName = "NeonGlow", botCount = 16, isMenuDemo = false) {
        this.snakes = [];
        this.snakesMap.clear();
        this.foods = [];
        this.foodsMap.clear();
        this.wisps = [];
        this.particles = [];
        this.floatingTexts = [];
        this.shakeIntensity = 0;
        this.shakeTimer = 0;
        this.isPaused = false;
        this.isMenuDemo = isMenuDemo;

        // Player snake starts with length 52 for an empowering beginner experience
        const skin = this.skins[this.selectedSkinIndex] || this.skins[0];
        this.player = new Snake('local_player', playerName, 0, 0, {
            isPlayer: !isMenuDemo,
            isBot: isMenuDemo,
            skin,
            initialLength: 52
        });
        this.player.turnSpeedMultiplier = this.turnSensitivity;

        this.player.onDeath = (reason, killer) => {
            if (!this.isMenuDemo && this.onPlayerDeath) {
                this.onPlayerDeath(this.player, reason, killer ? killer.name : null);
            } else if (this.isMenuDemo) {
                // Respawn gently in ambient menu demo
                this.player.x = (Math.random() - 0.5) * 400;
                this.player.y = (Math.random() - 0.5) * 400;
                this.player.isAlive = true;
                this.player.length = 52;
            }
        };

        this.snakes.push(this.player);
        this.snakesMap.set(this.player.id, this.player);

        if (this.offlineFallbackTimer) {
            clearTimeout(this.offlineFallbackTimer);
            this.offlineFallbackTimer = null;
        }

        if (!isMenuDemo) {
            // Attempt multiplayer WebSocket connection
            this.network.connect(playerName, this.selectedSkinIndex);

            // Set up offline backup bots and food in case server is unavailable
            this.offlineFallbackTimer = setTimeout(() => {
                if (!this.multiplayerConnected) {
                    this.isMultiplayer = false;
                    this.spawnOfflineBots(botCount);
                    this.populateInitialFood(this.graphicsQuality === 'low' ? 450 : 750);
                    this.spawnLocalWisps(5);
                }
            }, 1200);
        } else {
            // Ambient demo mode on main menu
            this.isMultiplayer = false;
            this.spawnOfflineBots(12);
            this.populateInitialFood(400);
            this.spawnLocalWisps(4);
        }

        this.isRunning = true;
        this.lastTime = performance.now();
        requestAnimationFrame((t) => this.gameLoop(t));
    }

    spawnOfflineBots(botCount = 30) {
        const botNames = [
            'NeonKing', 'CyberViper', 'GlowMaster', 'NightCrawler', 'ViperX', 'PlasmaHydra',
            'LaserBite', 'AeroPhantom', 'QuantumWorm', 'ByteNommer', 'HyperCoil', 'SynthStalker',
            'AetherSerpent', 'NovaCobra', 'Solaris', 'Ghost_Runner', 'Zenith', 'ZeroGravity',
            'Omega_Hydra', 'ApexPredator', 'VoltSerpent', 'RadiantBoa', 'EchoPulse', 'ShadowFang',
            'GlitchWorm', 'VenomMatrix', 'TitanPython', 'CosmicEel', 'PrismAdder', 'AbyssCrawler',
            'StarlightBoa', 'PulseViper', 'NeonEclipse', 'VortexMamba', 'SpecterWorm', 'ChronoSerpent'
        ];

        for (let i = 0; i < botCount; i++) {
            this.spawnBot(botNames[i % botNames.length]);
        }
    }

    spawnBot(name) {
        const angle = Math.random() * Math.PI * 2;
        const dist = (0.2 + Math.random() * 0.72) * this.radius;
        const bx = Math.cos(angle) * dist;
        const by = Math.sin(angle) * dist;

        const botSkin = this.skins[Math.floor(Math.random() * this.skins.length)];
        const bot = new BotSnake(`bot_${Date.now()}_${Math.random()}`, name, bx, by, {
            isPlayer: false,
            skin: botSkin,
            initialLength: 24 + Math.random() * 55
        });

        bot.onDeath = () => {
            setTimeout(() => {
                if (this.isRunning && !this.isPaused && !this.isMultiplayer) {
                    this.spawnBot(name);
                }
            }, 3000);
        };

        this.snakes.push(bot);
        this.snakesMap.set(bot.id, bot);
    }

    populateInitialFood(count = 900) {
        for (let i = 0; i < count; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = Math.sqrt(Math.random()) * (this.radius * 0.96);
            const fx = Math.cos(angle) * dist;
            const fy = Math.sin(angle) * dist;

            const roll = Math.random();
            let type = 'small';
            if (roll > 0.96) type = 'large';
            else if (roll > 0.8) type = 'medium';

            this.spawnFood(fx, fy, type);
        }
    }

    spawnFood(x, y, type = 'small') {
        const colors = {
            small: ['#10b981', '#06b6d4', '#8b5cf6', '#ec4899', '#f97316', '#3b82f6', '#ef4444'],
            medium: ['#0284c7', '#84cc16', '#db2777', '#f59e0b'],
            large: ['#eab308', '#ec4899', '#06b6d4', '#8b5cf6'],
            death: ['#eab308', '#ec4899', '#0284c7', '#84cc16', '#f97316'],
            boost: ['#0284c7', '#ec4899']
        };

        const palette = colors[type] || colors.small;
        const color = palette[Math.floor(Math.random() * palette.length)];

        let size = 1.3;
        let growth = 0.22;
        let scoreVal = 5;

        if (type === 'medium') {
            size = 2.5;
            growth = 0.65;
            scoreVal = 15;
        } else if (type === 'large') {
            size = 3.8;
            growth = 1.6;
            scoreVal = 45;
        } else if (type === 'death') {
            size = 4.2 + Math.random() * 1.5;
            growth = 2.4;
            scoreVal = 65;
        } else if (type === 'boost') {
            size = 1.1;
            growth = 0.15;
            scoreVal = 3;
        }

        const food = {
            id: `food_${Math.random()}`,
            x,
            y,
            type,
            size,
            growth,
            scoreVal,
            color,
            pulseOffset: Math.random() * Math.PI * 2
        };

        this.foods.push(food);
        this.foodsMap.set(food.id, food);
        return food;
    }

    spawnLocalWisps(count = 6) {
        for (let i = 0; i < count; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = (0.2 + Math.random() * 0.7) * this.radius;
            this.wisps.push({
                id: `wisp_${i}`,
                x: Math.cos(angle) * dist,
                y: Math.sin(angle) * dist,
                vx: (Math.random() - 0.5) * 3,
                vy: (Math.random() - 0.5) * 3,
                speed: 3.5,
                color: ['#ffe600', '#00f0ff', '#ff00aa', '#00ff66'][i % 4],
                wanderAngle: Math.random() * Math.PI * 2,
                scoreVal: 120,
                growth: 4.5
            });
        }
    }

    spawnExplosion(x, y, color = '#00f0ff', count = 28) {
        for (let i = 0; i < count; i++) {
            const angle = Math.random() * Math.PI * 2;
            const speed = 70 + Math.random() * 290;
            this.particles.push({
                x,
                y,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed,
                life: 0.5 + Math.random() * 0.45,
                maxLife: 0.95,
                size: 2.5 + Math.random() * 4,
                color
            });
        }
    }

    spawnBoostParticle(x, y, color = '#00f0ff') {
        const angle = Math.random() * Math.PI * 2;
        const speed = 25 + Math.random() * 60;
        this.particles.push({
            x,
            y,
            vx: Math.cos(angle) * speed,
            vy: Math.sin(angle) * speed,
            life: 0.28,
            maxLife: 0.28,
            size: 2.2 + Math.random() * 2.5,
            color
        });
    }

    pause() {
        this.isPaused = true;
    }

    resume() {
        this.isPaused = false;
        this.lastTime = performance.now();
    }

    togglePause() {
        if (this.isPaused) {
            this.resume();
        } else {
            this.pause();
        }
        return this.isPaused;
    }

    gameLoop(now) {
        if (!this.isRunning) return;

        // Hard cap dt to max 50ms (20 FPS equivalent) to prevent position jumps during lag spikes.
        // This means at very low FPS the game slows rather than teleporting entities.
        const rawDt = (now - this.lastTime) / 1000;
        const dt = Math.min(0.050, Math.max(0.001, rawDt));
        this.lastTime = now;
        this.frameCount++;

        if (this.frameCount % 20 === 0 && rawDt > 0) {
            this.fps = Math.round(1 / rawDt);
        }

        if (!this.isPaused) {
            this.update(dt);
        }

        this.render();

        if (this.onFrame) {
            this.onFrame(dt);
        }

        requestAnimationFrame((t) => this.gameLoop(t));
    }

    update(dt) {
        // 1. Client prediction: update player kinematics.
        // NOTE: steering (targetAngle) is set by input events in real-time,
        // NOT re-applied here, to avoid double-processing that causes stuttering.
        if (this.player && this.player.isAlive) {
            this.player.turnSpeedMultiplier = this.turnSensitivity;
            this.player.update(dt, this);
        }

        // 2. Smooth dead reckoning for remote snakes in multiplayer mode (60 FPS fluid glide)
        if (this.isMultiplayer) {
            for (let i = 0; i < this.snakes.length; i++) {
                const s = this.snakes[i];
                if (s !== this.player && s.isAlive) {
                    s.updateRemote(dt);
                }
            }
        } else {
            // Offline simulation update (only when in solo/offline mode)
            this.updateOfflineSimulation(dt);
        }

        // 3. Update particles
        for (let i = this.particles.length - 1; i >= 0; i--) {
            const p = this.particles[i];
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.vx *= 0.95;
            p.vy *= 0.95;
            p.life -= dt;
            if (p.life <= 0) {
                this.particles.splice(i, 1);
            }
        }

        // 4. Update floating score texts
        for (let i = this.floatingTexts.length - 1; i >= 0; i--) {
            const ft = this.floatingTexts[i];
            ft.y += ft.vy * dt;
            ft.life -= dt;
            if (ft.life <= 0) {
                this.floatingTexts.splice(i, 1);
            }
        }

        // 5. Update screen shake
        if (this.shakeTimer > 0) {
            this.shakeTimer -= dt;
            if (this.shakeTimer <= 0) this.shakeIntensity = 0;
        }

        // 6. Camera follow with smooth zoom (frame-rate independent easing)
        if (this.player) {
            const camFollow = 1 - Math.exp(-7.5 * dt);
            this.camera.x += (this.player.x - this.camera.x) * camFollow;
            this.camera.y += (this.player.y - this.camera.y) * camFollow;

            const targetZ = Math.max(0.60, 1.06 - (this.player.length / 550) * 0.38);
            const zoomFollow = 1 - Math.exp(-3.0 * dt);
            this.camera.zoom += (targetZ - this.camera.zoom) * zoomFollow;
        }
    }

    updateOfflineSimulation(dt) {
        // ---- 1. Move all bots ----
        for (let i = 0; i < this.snakes.length; i++) {
            const snake = this.snakes[i];
            if (!snake.isAlive) continue;
            if (snake instanceof BotSnake) snake.updateAI(dt, this);
        }

        // ---- 2. Update wisps ----
        for (let i = 0; i < this.wisps.length; i++) {
            const wisp = this.wisps[i];
            wisp.wanderAngle = (wisp.wanderAngle || 0) + (Math.random() - 0.5) * 1.5 * dt;

            let fleeX = 0, fleeY = 0, threatened = false;
            for (const snake of this.snakes) {
                if (!snake.isAlive) continue;
                const dx = wisp.x - snake.x, dy = wisp.y - snake.y;
                const dSq = dx * dx + dy * dy;
                if (dSq < 180 * 180) {
                    const dist = Math.sqrt(dSq);
                    fleeX += (dx / dist) * 4.0;
                    fleeY += (dy / dist) * 4.0;
                    threatened = true;
                }
            }
            if (threatened) { wisp.wanderAngle = Math.atan2(fleeY, fleeX); wisp.speed = 6.8; }
            else wisp.speed = 3.5;

            wisp.x += Math.cos(wisp.wanderAngle) * wisp.speed * 60 * dt;
            wisp.y += Math.sin(wisp.wanderAngle) * wisp.speed * 60 * dt;
            const wDist = Math.hypot(wisp.x, wisp.y);
            if (wDist > this.radius * 0.95) {
                wisp.wanderAngle = Math.atan2(-wisp.y, -wisp.x);
                wisp.x *= (this.radius * 0.94) / wDist;
                wisp.y *= (this.radius * 0.94) / wDist;
            }
        }

        // ================================================================
        // 3. SPATIAL GRID — broad-phase body-segment index
        // ================================================================
        // Rebuilt every frame. Each living snake inserts its body segments
        // (excluding the head at index 0, and a short grace zone behind the
        // head so that sharp turns don't self-collide) with their true radius.
        //
        // Cell size 60: fits ~2 snake widths per cell — good balance between
        // cells-per-query and entries-per-cell across all snake sizes.
        // ================================================================
        if (!this._segGrid) this._segGrid = new SpatialGrid(60);
        const segGrid = this._segGrid;
        segGrid.clear();

        // Food grid for O(1) pickup
        if (!this._foodGrid) this._foodGrid = new SpatialGrid(100);
        const foodGrid = this._foodGrid;
        foodGrid.clear();

        for (let i = 0; i < this.snakes.length; i++) {
            const snake = this.snakes[i];
            if (!snake.isAlive) continue;
            const segR = snake.width * 0.5;
            const segs = snake.segments;
            // Grace zone: skip the first GRACE_SEGS behind the head so
            // a snake cannot kill itself on a sharp turn.  8 segments at
            // spacing=6 = 48 px grace, comfortably larger than any head radius.
            const GRACE = 8;
            for (let s = GRACE; s < segs.length; s++) {
                segGrid.insert(segs[s].x, segs[s].y, segR, { snake, segIdx: s });
            }
        }

        // Populate food grid
        for (let f = 0; f < this.foods.length; f++) {
            const food = this.foods[f];
            foodGrid.insert(food.x, food.y, 6, food);
        }

        // ================================================================
        // 4. COLLISION DETECTION — swept capsule + head-to-head
        // ================================================================
        // Phase A: head vs enemy body segments (swept capsule narrow-phase).
        // Phase B: head vs enemy head (mutual kill when two heads overlap).
        // Deaths collected first, resolved after loops to keep state consistent.
        // ================================================================
        const toKill = []; // { victim, killer }

        for (let i = 0; i < this.snakes.length; i++) {
            const snakeA = this.snakes[i];
            if (!snakeA.isAlive) continue;

            // Capsule endpoints: previous head → current head
            const ax0 = (snakeA.prevX !== undefined) ? snakeA.prevX : snakeA.x;
            const ay0 = (snakeA.prevY !== undefined) ? snakeA.prevY : snakeA.y;
            const ax1 = snakeA.x;
            const ay1 = snakeA.y;
            const amx = ax1 - ax0;
            const amy = ay1 - ay0;
            const aMoveLenSq = amx * amx + amy * amy;

            const headR = snakeA.width * 0.5;
            // Broad-phase query radius: half capsule + head radius + max segment radius (18)
            const capsuleHalfLen = Math.sqrt(aMoveLenSq) * 0.5;
            const qx = (ax0 + ax1) * 0.5;
            const qy = (ay0 + ay1) * 0.5;
            const qr = capsuleHalfLen + headR + 20;

            // ---- Phase A: head vs body ----
            let killed = false;
            const candidates = segGrid.query(qx, qy, qr);
            for (const entry of candidates) {
                if (killed) break;
                const snakeB = entry.data.snake;
                if (snakeB === snakeA || !snakeB.isAlive) continue;

                const seg = snakeB.segments[entry.data.segIdx];
                if (!seg) continue;

                // Combined radius: slightly tighter (0.42) to prevent false positives
                // from very thin visual overlaps at segment ends.
                const hitR = (headR + snakeB.width * 0.5) * 0.92;
                const hitRSq = hitR * hitR;

                // Current-position point test
                let dx = ax1 - seg.x, dy = ay1 - seg.y;
                if (dx * dx + dy * dy < hitRSq) {
                    killed = true;
                    toKill.push({ victim: snakeA, killer: snakeB });
                    break;
                }

                // Swept test — catches tunnelling at any speed
                // Threshold 0.5² so even slow snakes get continuous detection.
                if (aMoveLenSq > 0.25) {
                    const tx = seg.x - ax0, ty = seg.y - ay0;
                    let t = (tx * amx + ty * amy) / aMoveLenSq;
                    t = Math.max(0, Math.min(1, t));
                    const ex = ax0 + t * amx - seg.x;
                    const ey = ay0 + t * amy - seg.y;
                    if (ex * ex + ey * ey < hitRSq) {
                        killed = true;
                        toKill.push({ victim: snakeA, killer: snakeB });
                        break;
                    }
                }
            }

            if (killed) continue;

            // ---- Phase B: head-to-head mutual kill ----
            // Only test pairs once (j > i) to avoid double-kill pushes.
            for (let j = i + 1; j < this.snakes.length; j++) {
                const snakeB = this.snakes[j];
                if (!snakeB.isAlive) continue;

                const h2hR = (headR + snakeB.width * 0.5) * 0.85; // slightly tighter for heads
                const dx = ax1 - snakeB.x;
                const dy = ay1 - snakeB.y;
                if (dx * dx + dy * dy < h2hR * h2hR) {
                    // Both die — smaller snake is 'killed by' the larger one
                    if (snakeA.length >= snakeB.length) {
                        toKill.push({ victim: snakeB, killer: snakeA });
                    } else {
                        toKill.push({ victim: snakeA, killer: snakeB });
                    }
                    break;
                }
            }
        }

        // ---- Resolve deaths (deferred to avoid mid-loop state mutation) ----
        for (const { victim, killer } of toKill) {
            if (!victim.isAlive) continue; // already killed this frame
            victim.die(this, 'collision', killer);
            killer.kills++;
            killer.grow(3.5, 250);
            if (killer.isPlayer) {
                this.spawnFloatingText('KILL +250!', victim.x, victim.y - 20, '#ff007f');
                this.triggerScreenShake(10, 0.35);
            }
            if (this.onKill && killer.isPlayer) this.onKill(victim);
            if (this.onKillFeed) this.onKillFeed({ killerName: killer.name, victimName: victim.name });
        }

        // ================================================================
        // 5. FOOD & WISP PICKUP — spatial query + swept continuous check
        // ================================================================
        // We collect IDs to remove in a Set and do a single filtered pass
        // at the end, avoiding repeated O(N) indexOf calls.
        // ================================================================
        const eatenIds = new Set();

        for (let s = 0; s < this.snakes.length; s++) {
            const snake = this.snakes[s];
            if (!snake.isAlive) continue;

            // Pickup radius = head radius + 60% extra (forgiving but not excessive)
            const pickupR = snake.width * 0.5 + snake.width * 0.6 + 4;
            const pickupRSq = pickupR * pickupR;

            // Previous head position for swept food pickup
            const px0 = (snake.prevX !== undefined) ? snake.prevX : snake.x;
            const py0 = (snake.prevY !== undefined) ? snake.prevY : snake.y;
            const pmx = snake.x - px0;
            const pmy = snake.y - py0;
            const pMoveLenSq = pmx * pmx + pmy * pmy;

            // Query food grid — only candidates near the head
            const nearbyFood = foodGrid.query(snake.x, snake.y, pickupR + Math.sqrt(pMoveLenSq) + 6);

            for (const entry of nearbyFood) {
                const food = entry.data;
                if (!this.foodsMap.has(food.id) || eatenIds.has(food.id)) continue;

                // Current-position check (head)
                let dx = snake.x - food.x, dy = snake.y - food.y;
                let eaten = dx * dx + dy * dy < pickupRSq;

                // Swept check for head (catches high-speed passing over pellets)
                if (!eaten && pMoveLenSq > 0.25) {
                    const tx = food.x - px0, ty = food.y - py0;
                    let t = (tx * pmx + ty * pmy) / pMoveLenSq;
                    t = Math.max(0, Math.min(1, t));
                    const ex = px0 + t * pmx - food.x;
                    const ey = py0 + t * pmy - food.y;
                    eaten = ex * ex + ey * ey < pickupRSq;
                }

                // Near-neck body check (first 3 segments)
                if (!eaten) {
                    const checkN = Math.min(4, snake.segments.length);
                    for (let si = 1; si < checkN && !eaten; si++) {
                        const seg = snake.segments[si];
                        dx = seg.x - food.x; dy = seg.y - food.y;
                        eaten = dx * dx + dy * dy < pickupRSq;
                    }
                }

                if (eaten) {
                    eatenIds.add(food.id);
                    snake.grow(food.growth, food.scoreVal);
                    this.foodsMap.delete(food.id);
                    if (snake.isPlayer) {
                        if (food.type === 'large' || food.type === 'death') {
                            this.spawnFloatingText(`+${food.scoreVal}`, food.x, food.y, '#ffe600');
                        }
                        if (this.onPlayerEat) this.onPlayerEat(food);
                    }
                }
            }

            // Wisps — linear scan is fine (few exist)
            for (let w = this.wisps.length - 1; w >= 0; w--) {
                const wisp = this.wisps[w];
                const dx = snake.x - wisp.x, dy = snake.y - wisp.y;
                if (dx * dx + dy * dy < (pickupR + 12) * (pickupR + 12)) {
                    snake.grow(wisp.growth, wisp.scoreVal);
                    this.wisps.splice(w, 1);
                    if (snake.isPlayer) {
                        this.spawnFloatingText(`\u2728 WISP +${wisp.scoreVal}`, wisp.x, wisp.y, '#ffe600');
                        this.triggerScreenShake(7, 0.25);
                        if (this.onPlayerEat) this.onPlayerEat(wisp, true);
                    }
                }
            }
        }

        // Remove all eaten food in a single pass (O(N) total, not O(N²))
        if (eatenIds.size > 0) {
            this.foods = this.foods.filter(f => !eatenIds.has(f.id));
        }

        // ================================================================
        // 6. REPLENISH AMBIENT FOOD (distributed, small batches)
        // ================================================================
        const targetFoodCount = this.graphicsQuality === 'low' ? 600 : 1000;
        if (this.foods.length < targetFoodCount) {
            const missing = Math.min(12, targetFoodCount - this.foods.length);
            for (let i = 0; i < missing; i++) {
                const angle = Math.random() * Math.PI * 2;
                const dist = Math.sqrt(Math.random()) * (this.radius * 0.96);
                const roll = Math.random();
                let type = 'small';
                if (roll > 0.96) type = 'large';
                else if (roll > 0.82) type = 'medium';
                this.spawnFood(Math.cos(angle) * dist, Math.sin(angle) * dist, type);
            }
        }
    }

    render() {
        const ctx = this.ctx;
        const w = this.width;
        const h = this.height;

        ctx.fillStyle = '#141720';
        ctx.fillRect(0, 0, w, h);

        ctx.save();

        // Screen shake
        if (this.shakeIntensity > 0) {
            const shakeX = (Math.random() - 0.5) * this.shakeIntensity * 2;
            const shakeY = (Math.random() - 0.5) * this.shakeIntensity * 2;
            ctx.translate(shakeX, shakeY);
        }

        // Camera transform
        ctx.translate(w / 2, h / 2);
        ctx.scale(this.camera.zoom, this.camera.zoom);
        ctx.translate(-this.camera.x, -this.camera.y);

        // Dark arena floor
        ctx.fillStyle = '#1e2235';
        ctx.beginPath();
        ctx.arc(0, 0, this.radius, 0, Math.PI * 2);
        ctx.fill();

        // Viewport bounds for culling
        const viewW = w / this.camera.zoom;
        const viewH = h / this.camera.zoom;
        const viewLeft = this.camera.x - viewW / 2 - 140;
        const viewRight = this.camera.x + viewW / 2 + 140;
        const viewTop = this.camera.y - viewH / 2 - 140;
        const viewBottom = this.camera.y + viewH / 2 + 140;

        // Draw arena grid
        this.renderCyberGrid(ctx, viewLeft, viewRight, viewTop, viewBottom);

        // Draw arena perimeter barrier
        this.renderBoundary(ctx);

        // Draw food pellets
        this.renderFood(ctx, viewLeft, viewRight, viewTop, viewBottom);

        // Draw Moving Wisps
        this.renderWisps(ctx, viewLeft, viewRight, viewTop, viewBottom);

        // Draw snakes with viewport culling
        this.renderSnakes(ctx, viewLeft, viewRight, viewTop, viewBottom);

        // Draw particles
        this.renderParticles(ctx);

        // Draw floating score popups
        this.renderFloatingTexts(ctx);

        ctx.restore();

        // Minimap Radar (bottom right)
        this.renderMinimapRadar(ctx, w, h);

        // Warning vignette when near boundary
        if (this.player && this.player.isAlive && this.player.distanceToBorder < 500) {
            this.renderBorderWarning(ctx, w, h);
        }

        // Paused visual overlay
        if (this.isPaused) {
            ctx.fillStyle = 'rgba(10, 12, 18, 0.55)';
            ctx.fillRect(0, 0, w, h);
        }
    }

    renderCyberGrid(ctx, left, right, top, bottom) {
        const gridSize = 140;
        const startX = Math.floor(left / gridSize) * gridSize;
        const endX = Math.ceil(right / gridSize) * gridSize;
        const startY = Math.floor(top / gridSize) * gridSize;
        const endY = Math.ceil(bottom / gridSize) * gridSize;

        ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        for (let x = startX; x <= endX; x += gridSize) {
            ctx.moveTo(x, startY);
            ctx.lineTo(x, endY);
        }
        for (let y = startY; y <= endY; y += gridSize) {
            ctx.moveTo(startX, y);
            ctx.lineTo(endX, y);
        }
        ctx.stroke();

        // Subtle intersection dots
        ctx.fillStyle = 'rgba(255, 255, 255, 0.10)';
        for (let x = startX; x <= endX; x += gridSize) {
            for (let y = startY; y <= endY; y += gridSize) {
                if ((x * x + y * y) < this.radius * this.radius) {
                    ctx.fillRect(x - 1, y - 1, 2, 2);
                }
            }
        }
    }

    renderBoundary(ctx) {
        ctx.save();
        ctx.strokeStyle = 'rgba(239, 68, 68, 0.55)';
        ctx.lineWidth = 6;
        ctx.beginPath();
        ctx.arc(0, 0, this.radius, 0, Math.PI * 2);
        ctx.stroke();

        ctx.strokeStyle = 'rgba(239, 68, 68, 0.85)';
        ctx.lineWidth = 2.5;
        ctx.setLineDash([12, 12]);
        ctx.beginPath();
        ctx.arc(0, 0, this.radius, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
    }

    renderFood(ctx, left, right, top, bottom) {
        const time = performance.now() * 0.003;
        const isHigh = this.graphicsQuality === 'high';

        for (let i = 0; i < this.foods.length; i++) {
            const f = this.foods[i];
            if (f.x < left || f.x > right || f.y < top || f.y > bottom) continue;

            const pulse = 1.0 + Math.sin(time + f.pulseOffset) * 0.22;
            const r = f.size * 3.2 * pulse;

            ctx.fillStyle = f.color;
            ctx.beginPath();
            ctx.arc(f.x, f.y, r, 0, Math.PI * 2);
            ctx.fill();

            // Subtle rim on dark background
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.14)';
            ctx.lineWidth = 0.6;
            ctx.stroke();

            if (f.type === 'large' || f.type === 'death') {
                ctx.fillStyle = 'rgba(255,255,255,0.85)';
                ctx.beginPath();
                ctx.arc(f.x, f.y, r * 0.45, 0, Math.PI * 2);
                ctx.fill();
            }
        }
    }

    renderWisps(ctx, left, right, top, bottom) {
        const time = performance.now() * 0.005;

        for (let i = 0; i < this.wisps.length; i++) {
            const w = this.wisps[i];
            if (w.x < left || w.x > right || w.y < top || w.y > bottom) continue;

            const pulse = 1.0 + Math.sin(time * 3 + i) * 0.25;
            const radius = 9 * pulse;

            ctx.save();
            ctx.translate(w.x, w.y);

            // Outer soft halo
            ctx.strokeStyle = w.color || '#f59e0b';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(0, 0, radius * 1.4, 0, Math.PI * 2);
            ctx.stroke();

            // Core
            ctx.fillStyle = w.color || '#f59e0b';
            ctx.beginPath();
            ctx.arc(0, 0, radius, 0, Math.PI * 2);
            ctx.fill();

            // Crisp dark rim
            ctx.strokeStyle = 'rgba(15, 23, 42, 0.2)';
            ctx.lineWidth = 1;
            ctx.stroke();

            // Bright sparkling center
            ctx.fillStyle = '#ffffff';
            ctx.beginPath();
            ctx.arc(0, 0, radius * 0.45, 0, Math.PI * 2);
            ctx.fill();

            ctx.restore();
        }
    }

    renderSnakes(ctx, viewLeft, viewRight, viewTop, viewBottom) {
        const isHigh = this.graphicsQuality === 'high';

        // Render opponents first and player snake last for clear visual layering
        const renderList = [];
        let playerSnake = null;
        for (let s = 0; s < this.snakes.length; s++) {
            const snake = this.snakes[s];
            if (!snake.isAlive) continue;
            if (snake.isPlayer) {
                playerSnake = snake;
            } else {
                renderList.push(snake);
            }
        }
        if (playerSnake) {
            renderList.push(playerSnake);
        }

        for (let s = 0; s < renderList.length; s++) {
            const snake = renderList[s];
            const segs = snake.segments;
            const segCount = segs.length;
            if (segCount === 0) continue;

            // Viewport culling: skip drawing off-screen snakes to maximize FPS
            if (viewLeft !== undefined && !snake.isPlayer) {
                const margin = snake.width * 2 + 100;
                const headInView = (
                    snake.x >= viewLeft - margin &&
                    snake.x <= viewRight + margin &&
                    snake.y >= viewTop - margin &&
                    snake.y <= viewBottom + margin
                );

                if (!headInView) {
                    const mid = segs[Math.floor(segCount / 2)];
                    const tail = segs[segCount - 1];
                    const midInView = mid && (mid.x >= viewLeft - 60 && mid.x <= viewRight + 60 && mid.y >= viewTop - 60 && mid.y <= viewBottom + 60);
                    const tailInView = tail && (tail.x >= viewLeft - 60 && tail.x <= viewRight + 60 && tail.y >= viewTop - 60 && tail.y <= viewBottom + 60);
                    if (!midInView && !tailInView) {
                        continue; // Culled from rendering!
                    }
                }
            }

            // Draw body vertebrae from tail to head
            for (let i = segCount - 1; i >= 0; i--) {
                const seg = segs[i];
                const t = i / segCount;
                const segWidth = snake.width * (0.84 + 0.16 * (1 - t));

                // Alternating vibrant body segments
                ctx.fillStyle = (i % 2 === 0) ? snake.skin.primary : snake.skin.secondary;
                ctx.beginPath();
                ctx.arc(seg.x, seg.y, segWidth / 2, 0, Math.PI * 2);
                ctx.fill();

                // Subtle crisp rim for visual prominence against light canvas
                ctx.strokeStyle = 'rgba(15, 23, 42, 0.12)';
                ctx.lineWidth = 0.8;
                ctx.stroke();

                // Specular highlight (offset top-left for tactile depth)
                if (isHigh) {
                    const specRadius = segWidth * 0.22;
                    const offX = -segWidth * 0.14;
                    const offY = -segWidth * 0.14;
                    ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
                    ctx.beginPath();
                    ctx.arc(seg.x + offX, seg.y + offY, specRadius, 0, Math.PI * 2);
                    ctx.fill();
                }
            }

            // Head
            ctx.save();
            ctx.translate(snake.x, snake.y);
            ctx.rotate(snake.angle);

            // Sleek aerodynamic head geometry
            ctx.fillStyle = snake.skin.primary;
            ctx.beginPath();
            ctx.ellipse(0, 0, snake.width * 0.72, snake.width * 0.56, 0, 0, Math.PI * 2);
            ctx.fill();

            // Head rim
            ctx.strokeStyle = 'rgba(15, 23, 42, 0.16)';
            ctx.lineWidth = 1;
            ctx.stroke();

            // Head specular highlight
            if (isHigh) {
                ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
                ctx.beginPath();
                ctx.ellipse(-snake.width * 0.12, -snake.width * 0.12, snake.width * 0.34, snake.width * 0.22, 0, 0, Math.PI * 2);
                ctx.fill();
            }

            // Expressive Eyes
            const eyeDist = snake.width * 0.28;
            const eyeRadius = snake.width * 0.23 * (snake.isBoosting ? 1.15 : 1.0);

            // Sclera (White base)
            ctx.fillStyle = '#ffffff';
            ctx.beginPath();
            ctx.arc(snake.width * 0.22, -eyeDist, eyeRadius, 0, Math.PI * 2);
            ctx.arc(snake.width * 0.22, eyeDist, eyeRadius, 0, Math.PI * 2);
            ctx.fill();

            // Sclera subtle rim
            ctx.strokeStyle = 'rgba(15, 23, 42, 0.2)';
            ctx.lineWidth = 0.75;
            ctx.stroke();

            // Vibrant Iris
            ctx.fillStyle = snake.skin.glow || '#0284c7';
            const irisRadius = eyeRadius * 0.65;
            ctx.beginPath();
            ctx.arc(snake.width * 0.28, -eyeDist, irisRadius, 0, Math.PI * 2);
            ctx.arc(snake.width * 0.28, eyeDist, irisRadius, 0, Math.PI * 2);
            ctx.fill();

            // Pupils (dilates when boosting)
            const pupilRadius = irisRadius * (snake.isBoosting ? 0.78 : 0.48);
            ctx.fillStyle = '#0f172a';
            ctx.beginPath();
            ctx.arc(snake.width * 0.31, -eyeDist, pupilRadius, 0, Math.PI * 2);
            ctx.arc(snake.width * 0.31, eyeDist, pupilRadius, 0, Math.PI * 2);
            ctx.fill();

            // Glint specular
            ctx.fillStyle = 'rgba(255, 255, 255, 0.95)';
            ctx.beginPath();
            ctx.arc(snake.width * 0.24, -eyeDist - 1.5, 1.2, 0, Math.PI * 2);
            ctx.arc(snake.width * 0.24, eyeDist - 1.5, 1.2, 0, Math.PI * 2);
            ctx.fill();

            ctx.restore();

            // Floating Leader Halo for #1
            if (snake.isLeader) {
                this.renderCrown(ctx, snake.x, snake.y - snake.width - 24);
            }

            // Clean callsign label above snake with high-contrast white outline + dark slate fill
            ctx.font = `bold ${snake.isPlayer ? 13 : 11}px "Space Grotesk", sans-serif`;
            ctx.textAlign = 'center';
            const callsign = snake.name + (snake.isPlayer ? ' (YOU)' : '');
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.95)';
            ctx.lineWidth = 3.5;
            ctx.strokeText(callsign, snake.x, snake.y - snake.width - 8);
            ctx.fillStyle = snake.isPlayer ? '#2563eb' : '#0f172a';
            ctx.fillText(callsign, snake.x, snake.y - snake.width - 8);
        }
    }

    renderCrown(ctx, x, y) {
        const time = performance.now() * 0.003;
        const floatY = Math.sin(time * 2) * 3;

        ctx.save();
        ctx.translate(x, y + floatY);

        // Gold Halo Ring
        ctx.strokeStyle = '#d97706';
        ctx.lineWidth = 2.2;
        ctx.beginPath();
        ctx.ellipse(0, 0, 16, 5, 0, 0, Math.PI * 2);
        ctx.stroke();

        // Geometric crown pips
        ctx.fillStyle = '#f59e0b';
        for (let i = -1; i <= 1; i++) {
            const pipX = i * 11;
            const pipH = i === 0 ? 8 : 5;
            ctx.beginPath();
            ctx.moveTo(pipX, -pipH);
            ctx.lineTo(pipX + 2.5, 0);
            ctx.lineTo(pipX, 2);
            ctx.lineTo(pipX - 2.5, 0);
            ctx.closePath();
            ctx.fill();
        }

        ctx.restore();
    }

    renderParticles(ctx) {
        for (let i = 0; i < this.particles.length; i++) {
            const p = this.particles[i];
            const alpha = p.life / p.maxLife;
            ctx.fillStyle = p.color;
            ctx.globalAlpha = Math.max(0, alpha);
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.globalAlpha = 1.0;
    }

    renderFloatingTexts(ctx) {
        ctx.save();
        ctx.font = 'bold 15px "Outfit", sans-serif';
        ctx.textAlign = 'center';

        for (let i = 0; i < this.floatingTexts.length; i++) {
            const ft = this.floatingTexts[i];
            const alpha = ft.life / ft.maxLife;
            ctx.globalAlpha = Math.max(0, alpha);
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.95)';
            ctx.lineWidth = 3;
            ctx.strokeText(ft.text, ft.x, ft.y);
            ctx.fillStyle = ft.color;
            ctx.fillText(ft.text, ft.x, ft.y);
        }
        ctx.restore();
    }

    renderMinimapRadar(ctx, w, h) {
        const radarSize = 120;
        const margin = 20;
        const rx = w - radarSize / 2 - margin;
        const ry = h - radarSize / 2 - margin;
        const radarR = radarSize / 2;
        const time = performance.now() * 0.0018;

        ctx.save();

        // Light Frosted Base
        ctx.fillStyle = 'rgba(255, 255, 255, 0.92)';
        ctx.beginPath();
        ctx.arc(rx, ry, radarR, 0, Math.PI * 2);
        ctx.fill();

        // Concentric range rings
        ctx.strokeStyle = 'rgba(15, 23, 42, 0.06)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(rx, ry, radarR * 0.35, 0, Math.PI * 2);
        ctx.arc(rx, ry, radarR * 0.68, 0, Math.PI * 2);
        ctx.stroke();

        // Outer bezel ring
        ctx.strokeStyle = 'rgba(15, 23, 42, 0.12)';
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.arc(rx, ry, radarR, 0, Math.PI * 2);
        ctx.stroke();

        // Danger boundary barrier
        ctx.strokeStyle = 'rgba(239, 68, 68, 0.65)';
        ctx.lineWidth = 1.2;
        ctx.setLineDash([3, 3]);
        ctx.beginPath();
        ctx.arc(rx, ry, radarR * 0.94, 0, Math.PI * 2);
        ctx.stroke();
        ctx.setLineDash([]);

        // Rotating radar sweep line (subtle light sweep)
        const sweepAngle = time % (Math.PI * 2);
        const sweepX = rx + Math.cos(sweepAngle) * radarR;
        const sweepY = ry + Math.sin(sweepAngle) * radarR;
        const sweepGrad = ctx.createLinearGradient(rx, ry, sweepX, sweepY);
        sweepGrad.addColorStop(0, 'rgba(37, 99, 235, 0.01)');
        sweepGrad.addColorStop(1, 'rgba(37, 99, 235, 0.22)');
        ctx.strokeStyle = sweepGrad;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(rx, ry);
        ctx.lineTo(sweepX, sweepY);
        ctx.stroke();

        // Scale factor: world -> radar
        const scale = (radarR * 0.92) / this.radius;

        // Enemy snakes
        for (let i = 0; i < this.snakes.length; i++) {
            const s = this.snakes[i];
            if (!s.isAlive || s === this.player) continue;

            const px = rx + s.x * scale;
            const py = ry + s.y * scale;

            if (s.isLeader) {
                ctx.fillStyle = '#f59e0b';
                ctx.beginPath();
                ctx.arc(px, py, 3.2, 0, Math.PI * 2);
                ctx.fill();
            } else {
                ctx.fillStyle = 'rgba(239, 68, 68, 0.85)';
                ctx.beginPath();
                ctx.arc(px, py, 2.0, 0, Math.PI * 2);
                ctx.fill();
            }
        }

        // Player beacon
        if (this.player && this.player.isAlive) {
            const px = rx + this.player.x * scale;
            const py = ry + this.player.y * scale;
            const pulse = 1.0 + Math.sin(time * 6) * 0.2;

            // Pulse ring
            ctx.strokeStyle = 'rgba(37, 99, 235, 0.4)';
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.arc(px, py, 6 * pulse, 0, Math.PI * 2);
            ctx.stroke();

            // Beacon center
            ctx.fillStyle = '#2563eb';
            ctx.beginPath();
            ctx.arc(px, py, 3.2, 0, Math.PI * 2);
            ctx.fill();
        }

        ctx.restore();
    }

    renderBorderWarning(ctx, w, h) {
        const factor = (500 - this.player.distanceToBorder) / 500;
        const alpha = Math.min(0.55, factor * 0.6);

        const gradient = ctx.createRadialGradient(
            w / 2, h / 2, Math.min(w, h) * 0.35,
            w / 2, h / 2, Math.max(w, h) * 0.7
        );
        gradient.addColorStop(0, 'rgba(255, 0, 70, 0)');
        gradient.addColorStop(1, `rgba(255, 0, 70, ${alpha})`);

        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, w, h);
    }
}

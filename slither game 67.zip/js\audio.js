/**
 * Procedural Web Audio Engine for Slither Cyber UX
 * Generates futuristic audio feedback and cyberpunk background synthwave
 * completely in-browser with zero external audio assets required.
 */

export class SoundEngine {
    constructor() {
        this.ctx = null;
        this.soundEnabled = true;
        this.musicEnabled = true;
        this.sfxVolume = 0.35;
        this.musicVolume = 0.22;
        this.isMuted = false;

        // Music synthesizer state
        this.musicInterval = null;
        this.musicStep = 0;
        this.bgmNodes = [];
        this.filterNode = null;
        this.musicGain = null;
        this.isMusicPlaying = false;
    }

    init() {
        if (!this.ctx) {
            const AudioCtx = window.AudioContext || window.webkitAudioContext;
            if (AudioCtx) {
                this.ctx = new AudioCtx();
            }
        }
        if (this.ctx && this.ctx.state === 'suspended') {
            this.ctx.resume();
        }
    }

    toggleSound() {
        this.soundEnabled = !this.soundEnabled;
        return this.soundEnabled;
    }

    toggleMusic() {
        this.musicEnabled = !this.musicEnabled;
        if (!this.musicEnabled) {
            this.stopMusic();
        } else {
            this.startMusic();
        }
        return this.musicEnabled;
    }

    toggleMute() {
        this.isMuted = !this.isMuted;
        if (this.isMuted) {
            this.stopMusic();
        } else if (this.musicEnabled) {
            this.startMusic();
        }
        return this.isMuted;
    }

    startMusic() {
        if (this.isMuted || !this.musicEnabled || this.isMusicPlaying) return;
        this.init();
        if (!this.ctx) return;

        this.isMusicPlaying = true;
        this.musicStep = 0;

        // Master BGM gain
        this.musicGain = this.ctx.createGain();
        this.musicGain.gain.setValueAtTime(this.musicVolume, this.ctx.currentTime);
        this.musicGain.connect(this.ctx.destination);

        // Cyberpunk synth arpeggio notes (Frequencies in Hz: D2, A2, D3, F3, G3, A3, C4, D4)
        const bassLine = [73.42, 73.42, 87.31, 87.31, 98.00, 98.00, 110.00, 65.41];
        const arpLine = [
            293.66, 349.23, 440.00, 523.25, 587.33, 440.00, 349.23, 440.00,
            261.63, 329.63, 392.00, 523.25, 440.00, 392.00, 329.63, 293.66
        ];

        const stepDuration = 0.14; // 107 BPM 16th notes

        const playStep = () => {
            if (!this.isMusicPlaying || !this.ctx) return;

            const now = this.ctx.currentTime;
            const step = this.musicStep;

            // 1. Bass Pulse (every 2 steps)
            if (step % 2 === 0) {
                const bassFreq = bassLine[Math.floor(step / 2) % bassLine.length];
                const bassOsc = this.ctx.createOscillator();
                const bassGain = this.ctx.createGain();
                const bassFilter = this.ctx.createBiquadFilter();

                bassOsc.type = 'sawtooth';
                bassOsc.frequency.setValueAtTime(bassFreq, now);

                bassFilter.type = 'lowpass';
                bassFilter.frequency.setValueAtTime(320, now);
                bassFilter.Q.setValueAtTime(3, now);

                bassGain.gain.setValueAtTime(0.35, now);
                bassGain.gain.exponentialRampToValueAtTime(0.001, now + stepDuration * 1.9);

                bassOsc.connect(bassFilter);
                bassFilter.connect(bassGain);
                bassGain.connect(this.musicGain);

                bassOsc.start(now);
                bassOsc.stop(now + stepDuration * 2);
            }

            // 2. Cyber Arp
            const arpFreq = arpLine[step % arpLine.length];
            const arpOsc = this.ctx.createOscillator();
            const arpGain = this.ctx.createGain();
            const arpFilter = this.ctx.createBiquadFilter();

            arpOsc.type = 'square';
            arpOsc.frequency.setValueAtTime(arpFreq, now);

            // Sweeping cutoff filter
            const filterSweep = 800 + Math.sin(now * 0.4) * 600;
            arpFilter.type = 'lowpass';
            arpFilter.frequency.setValueAtTime(filterSweep, now);
            arpFilter.Q.setValueAtTime(4, now);

            arpGain.gain.setValueAtTime(0.08, now);
            arpGain.gain.exponentialRampToValueAtTime(0.001, now + stepDuration * 0.95);

            arpOsc.connect(arpFilter);
            arpFilter.connect(arpGain);
            arpGain.connect(this.musicGain);

            arpOsc.start(now);
            arpOsc.stop(now + stepDuration);

            this.musicStep = (this.musicStep + 1) % 64;
        };

        playStep();
        this.musicInterval = setInterval(playStep, stepDuration * 1000);
    }

    stopMusic() {
        this.isMusicPlaying = false;
        if (this.musicInterval) {
            clearInterval(this.musicInterval);
            this.musicInterval = null;
        }
        if (this.musicGain && this.ctx) {
            try {
                this.musicGain.gain.linearRampToValueAtTime(0, this.ctx.currentTime + 0.1);
            } catch (_) {}
        }
    }

    playEat(isDeathFood = false) {
        if (this.isMuted || !this.soundEnabled) return;
        this.init();
        if (!this.ctx) return;

        const now = this.ctx.currentTime;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = isDeathFood ? 'triangle' : 'sine';
        const baseFreq = isDeathFood ? 680 + Math.random() * 80 : 480 + Math.random() * 60;
        osc.frequency.setValueAtTime(baseFreq, now);
        osc.frequency.exponentialRampToValueAtTime(baseFreq * 1.6, now + 0.07);

        gain.gain.setValueAtTime(this.sfxVolume * (isDeathFood ? 0.35 : 0.18), now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(now);
        osc.stop(now + 0.09);
    }

    playKill() {
        if (this.isMuted || !this.soundEnabled) return;
        this.init();
        if (!this.ctx) return;

        const now = this.ctx.currentTime;

        // Dual harmonic fanfare
        [220, 330, 440, 660].forEach((freq, idx) => {
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();

            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(freq, now + idx * 0.04);
            osc.frequency.exponentialRampToValueAtTime(freq * 1.5, now + idx * 0.04 + 0.18);

            gain.gain.setValueAtTime(this.sfxVolume * 0.28, now + idx * 0.04);
            gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.04 + 0.24);

            osc.connect(gain);
            gain.connect(this.ctx.destination);

            osc.start(now + idx * 0.04);
            osc.stop(now + idx * 0.04 + 0.26);
        });
    }

    playDeath() {
        if (this.isMuted || !this.soundEnabled) return;
        this.init();
        if (!this.ctx) return;

        const now = this.ctx.currentTime;
        const osc = this.ctx.createOscillator();
        const noise = this.ctx.createBufferSource();
        const gain = this.ctx.createGain();

        // Low pitch doom drop
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(280, now);
        osc.frequency.exponentialRampToValueAtTime(32, now + 0.55);

        gain.gain.setValueAtTime(this.sfxVolume * 0.65, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.58);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(now);
        osc.stop(now + 0.6);
    }

    playClick() {
        if (this.isMuted || !this.soundEnabled) return;
        this.init();
        if (!this.ctx) return;

        const now = this.ctx.currentTime;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(1100, now);
        osc.frequency.exponentialRampToValueAtTime(450, now + 0.035);

        gain.gain.setValueAtTime(this.sfxVolume * 0.15, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(now);
        osc.stop(now + 0.045);
    }

    playPause() {
        if (this.isMuted || !this.soundEnabled) return;
        this.init();
        if (!this.ctx) return;

        const now = this.ctx.currentTime;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(600, now);
        osc.frequency.exponentialRampToValueAtTime(300, now + 0.12);

        gain.gain.setValueAtTime(this.sfxVolume * 0.25, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.13);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(now);
        osc.stop(now + 0.14);
    }

    playResume() {
        if (this.isMuted || !this.soundEnabled) return;
        this.init();
        if (!this.ctx) return;

        const now = this.ctx.currentTime;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(350, now);
        osc.frequency.exponentialRampToValueAtTime(700, now + 0.12);

        gain.gain.setValueAtTime(this.sfxVolume * 0.25, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.13);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(now);
        osc.stop(now + 0.14);
    }

    startBoost() {
        if (this.isMuted || !this.soundEnabled || this.boostOsc) return;
        this.init();
        if (!this.ctx) return;

        const now = this.ctx.currentTime;
        this.boostOsc = this.ctx.createOscillator();
        this.boostGain = this.ctx.createGain();
        this.boostFilter = this.ctx.createBiquadFilter();

        this.boostOsc.type = 'sawtooth';
        this.boostOsc.frequency.setValueAtTime(85, now);
        this.boostOsc.frequency.linearRampToValueAtTime(145, now + 0.35);

        this.boostFilter.type = 'lowpass';
        this.boostFilter.frequency.setValueAtTime(320, now);

        this.boostGain.gain.setValueAtTime(0.001, now);
        this.boostGain.gain.linearRampToValueAtTime(this.sfxVolume * 0.18, now + 0.1);

        this.boostOsc.connect(this.boostFilter);
        this.boostFilter.connect(this.boostGain);
        this.boostGain.connect(this.ctx.destination);

        this.boostOsc.start(now);
    }

    stopBoost() {
        if (this.boostGain && this.ctx) {
            try {
                this.boostGain.gain.linearRampToValueAtTime(0.0001, this.ctx.currentTime + 0.08);
            } catch (_) {}
        }
        if (this.boostOsc) {
            try {
                this.boostOsc.stop(this.ctx.currentTime + 0.1);
            } catch (_) {}
            this.boostOsc = null;
            this.boostGain = null;
            this.boostFilter = null;
        }
    }

    playWisp() {
        if (this.isMuted || !this.soundEnabled) return;
        this.init();
        if (!this.ctx) return;

        const now = this.ctx.currentTime;
        [523.25, 659.25, 783.99, 1046.50].forEach((freq, idx) => {
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();

            osc.type = 'sine';
            osc.frequency.setValueAtTime(freq, now + idx * 0.05);

            gain.gain.setValueAtTime(this.sfxVolume * 0.28, now + idx * 0.05);
            gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.05 + 0.25);

            osc.connect(gain);
            gain.connect(this.ctx.destination);

            osc.start(now + idx * 0.05);
            osc.stop(now + idx * 0.05 + 0.26);
        });
    }
}

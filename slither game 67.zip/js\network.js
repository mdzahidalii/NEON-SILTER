/**
 * NEON SLITHER - Client Network Controller
 * Handles WebSocket communication, input dispatch, state packet unpacking,
 * and automatic reconnection / offline fallback.
 */

export class NetworkManager {
    constructor() {
        this.ws = null;
        this.isConnected = false;
        this.isConnecting = false;
        this.playerId = null;
        this.lastInputTime = 0;
        this.lastAngle = null;
        this.lastBoosting = null;

        // Callbacks
        this.onInit = null;
        this.onState = null;
        this.onDead = null;
        this.onKillFeed = null;
        this.onConnect = null;
        this.onDisconnect = null;
    }

    connect(playerName, skinIndex) {
        if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
            this.sendJoin(playerName, skinIndex);
            return;
        }

        this.isConnecting = true;
        const isSecure = window.location.protocol === 'https:';
        const protocol = isSecure ? 'wss:' : 'ws:';
        const host = (window.location.host && window.location.host.trim() !== '') ? window.location.host : '127.0.0.1:3300';
        const wsUrl = `${protocol}//${host}`;

        try {
            this.ws = new WebSocket(wsUrl);

            this.ws.onopen = () => {
                this.isConnected = true;
                this.isConnecting = false;
                this.sendJoin(playerName, skinIndex);
                if (this.onConnect) this.onConnect();
            };

            this.ws.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    this.handlePacket(data);
                } catch (e) {
                    console.error("Failed to parse packet", e);
                }
            };

            this.ws.onclose = () => {
                const wasConnected = this.isConnected;
                this.isConnected = false;
                this.isConnecting = false;
                if (wasConnected && this.onDisconnect) {
                    this.onDisconnect();
                }
            };

            this.ws.onerror = (err) => {
                this.isConnecting = false;
                if (this.onDisconnect) this.onDisconnect(err);
            };
        } catch (err) {
            this.isConnecting = false;
            if (this.onDisconnect) this.onDisconnect(err);
        }
    }

    sendJoin(name, skinIndex) {
        if (!this.isConnected || !this.ws) return;
        this.ws.send(JSON.stringify({
            type: 'join',
            name,
            skinIndex
        }));
    }

    sendRespawn(name, skinIndex) {
        if (!this.isConnected || !this.ws) return;
        this.ws.send(JSON.stringify({
            type: 'respawn',
            name,
            skinIndex
        }));
    }

    sendInput(angle, isBoosting, force = false) {
        if (!this.isConnected || !this.ws) return;

        const now = performance.now();
        const boostChanged = isBoosting !== this.lastBoosting;
        const angleDiff = this.lastAngle !== null ? Math.abs(angle - this.lastAngle) : 1;

        // Dispatch immediately on boost change; otherwise throttle to ~35 Hz (28ms) with micro-angle filtering
        if (!force && !boostChanged) {
            if (now - this.lastInputTime < 28) return;
            if (angleDiff < 0.015 && now - this.lastInputTime < 80) return;
        }

        this.lastInputTime = now;
        this.lastAngle = angle;
        this.lastBoosting = isBoosting;

        this.ws.send(JSON.stringify({
            type: 'input',
            angle: Math.round(angle * 1000) / 1000,
            isBoosting
        }));
    }

    handlePacket(data) {
        if (!data || !data.type) return;

        if (data.type === 'init') {
            this.playerId = data.playerId;
            if (this.onInit) this.onInit(data);
        } else if (data.type === 'state') {
            if (this.onState) this.onState(data);
        } else if (data.type === 'dead') {
            if (this.onDead) this.onDead(data);
        }
    }

    disconnect() {
        if (this.ws) {
            try { this.ws.close(); } catch (_) {}
            this.ws = null;
        }
        this.isConnected = false;
        this.isConnecting = false;
    }
}

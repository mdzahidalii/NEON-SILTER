/**
 * Zero-Dependency HTTP Server for Slither.io ESN Web App
 * Runs with Node.js / agy-node
 */

const http = require('http');
const fs = require('fs');
const path = require('path');

const DEFAULT_PORT = parseInt(process.env.PORT, 10) || 3300;
const WEB_DIR = path.resolve(__dirname);
const DATA_DIR = path.resolve(__dirname, '..', 'backend', 'data');

const MIME_TYPES = {
    '.html': 'text/html; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.mjs': 'application/javascript; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon'
};

const server = http.createServer((req, res) => {
    // CORS headers
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') {
        res.writeHead(204);
        res.end();
        return;
    }

    const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    let pathname = decodeURIComponent(parsedUrl.pathname);

    // API: Save session to disk
    if (pathname === '/api/save_session' && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => { body += chunk; });
        req.on('end', () => {
            try {
                const sessionData = JSON.parse(body);
                const username = sessionData.metadata?.username || 'anonymous';
                const sessionId = sessionData.metadata?.session_id || `session_${Date.now()}`;
                
                const userDir = path.join(DATA_DIR, username);
                fs.mkdirSync(userDir, { recursive: true });

                const filePath = path.join(userDir, `${sessionId}.json`);
                fs.writeFileSync(filePath, JSON.stringify(sessionData, null, 2));

                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ status: 'ok', path: filePath }));
            } catch (err) {
                res.writeHead(500, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: err.message }));
            }
        });
        return;
    }

    // Static files
    if (pathname === '/' || pathname === '') {
        pathname = '/index.html';
    }

    const safePath = path.normalize(path.join(WEB_DIR, pathname));
    if (!safePath.startsWith(WEB_DIR)) {
        res.writeHead(403, { 'Content-Type': 'text/plain' });
        res.end('403 Forbidden');
        return;
    }

    fs.stat(safePath, (err, stats) => {
        if (err || !stats.isFile()) {
            res.writeHead(404, { 'Content-Type': 'text/plain' });
            res.end('404 Not Found');
            return;
        }

        const ext = path.extname(safePath).toLowerCase();
        const contentType = MIME_TYPES[ext] || 'application/octet-stream';

        res.writeHead(200, { 'Content-Type': contentType });
        const stream = fs.createReadStream(safePath);
        stream.pipe(res);
    });
});

const { exec } = require('child_process');
const { WebSocketServer } = require('./ws-server.js');
const { ArenaServer } = require('./arena-server.js');

// Initialize Server-Authoritative Real-Time Multiplayer Arena
const arena = new ArenaServer();
const wss = new WebSocketServer(server);

wss.on('connection', (socket) => {
    socket.on('message', (data) => {
        if (!data || typeof data !== 'object') return;

        if (data.type === 'join' || data.type === 'respawn') {
            arena.addPlayer(socket, data.name || 'NeonSnake', data.skinIndex || 0);
        } else if (data.type === 'input') {
            arena.handlePlayerInput(socket, data);
        }
    });

    socket.on('close', () => {
        arena.removePlayer(socket);
    });

    socket.on('error', () => {
        arena.removePlayer(socket);
    });
});

function startServer(port) {
    // Listen on dual-stack (IPv4 + IPv6) so both localhost and 127.0.0.1 resolve cleanly
    server.listen(port, () => {
        const localUrl = `http://localhost:${port}`;
        const ipv4Url = `http://127.0.0.1:${port}`;
        console.log(`\n======================================================`);
        console.log(`⚡ NEON SLITHER Multiplayer Game Server Online!`);
        console.log(`🌐 Localhost:   ${localUrl}`);
        console.log(`🌐 IPv4 Direct: ${ipv4Url}`);
        console.log(`🎮 Game Engine: Active (Smooth 60 FPS Real-Time Multiplayer Arena)`);
        console.log(`======================================================\n`);

        // Automatically launch browser when server is guaranteed listening
        if (process.env.NO_OPEN !== '1') {
            const openCmd = process.platform === 'win32' ? `start "" "${ipv4Url}"` :
                            process.platform === 'darwin' ? `open "${ipv4Url}"` :
                            `xdg-open "${ipv4Url}"`;
            exec(openCmd, (err) => {
                if (err) {
                    console.log(`[i] Open in your browser: ${ipv4Url}`);
                }
            });
        }

        setInterval(() => {}, 1000 * 60 * 60);
    });

    server.on('error', (err) => {
        if (err.code === 'EADDRINUSE') {
            console.warn(`[!] Port ${port} is in use. Trying port ${port + 1}...`);
            startServer(port + 1);
        } else {
            console.error('Server error:', err);
        }
    });
}

startServer(DEFAULT_PORT);


/**
 * Zero-Dependency RFC 6455 WebSocket Server for Node.js
 * Compatible with node and agy-node
 */

const crypto = require('crypto');

class WSClient {
    constructor(socket) {
        this.socket = socket;
        this.buffer = Buffer.alloc(0);
        this.listeners = {};

        this.socket.on('data', (chunk) => this.handleData(chunk));
        this.socket.on('close', () => this.emit('close'));
        this.socket.on('error', (err) => {
            this.emit('error', err);
            try { this.socket.destroy(); } catch (_) {}
        });
    }

    on(event, fn) {
        if (!this.listeners[event]) this.listeners[event] = [];
        this.listeners[event].push(fn);
    }

    emit(event, ...args) {
        if (this.listeners[event]) {
            for (const fn of this.listeners[event]) fn(...args);
        }
    }

    send(data) {
        if (this.socket.destroyed || !this.socket.writable) return;
        const payload = Buffer.from(typeof data === 'string' ? data : JSON.stringify(data));
        const len = payload.length;
        let header;

        if (len < 126) {
            header = Buffer.from([0x81, len]);
        } else if (len <= 65535) {
            header = Buffer.from([0x81, 126, (len >> 8) & 0xFF, len & 0xFF]);
        } else {
            header = Buffer.alloc(10);
            header[0] = 0x81;
            header[1] = 127;
            header.writeBigUInt64BE(BigInt(len), 2);
        }

        try {
            this.socket.write(Buffer.concat([header, payload]));
        } catch (_) {}
    }

    close() {
        try {
            this.socket.end();
        } catch (_) {}
    }

    handleData(chunk) {
        this.buffer = Buffer.concat([this.buffer, chunk]);

        while (this.buffer.length >= 2) {
            const firstByte = this.buffer[0];
            const secondByte = this.buffer[1];
            const opcode = firstByte & 0x0F;
            const masked = (secondByte & 0x80) !== 0;
            let payloadLen = secondByte & 0x7F;
            let offset = 2;

            if (payloadLen === 126) {
                if (this.buffer.length < offset + 2) break;
                payloadLen = this.buffer.readUInt16BE(offset);
                offset += 2;
            } else if (payloadLen === 127) {
                if (this.buffer.length < offset + 8) break;
                payloadLen = Number(this.buffer.readBigUInt64BE(offset));
                offset += 8;
            }

            let maskKey = null;
            if (masked) {
                if (this.buffer.length < offset + 4) break;
                maskKey = this.buffer.slice(offset, offset + 4);
                offset += 4;
            }

            if (this.buffer.length < offset + payloadLen) {
                // Incomplete frame, wait for more data
                break;
            }

            const rawPayload = this.buffer.slice(offset, offset + payloadLen);
            this.buffer = this.buffer.slice(offset + payloadLen);

            if (masked && maskKey) {
                for (let i = 0; i < rawPayload.length; i++) {
                    rawPayload[i] ^= maskKey[i % 4];
                }
            }

            if (opcode === 0x8) {
                // Connection close
                this.socket.end();
                return;
            } else if (opcode === 0x9) {
                // Ping frame -> reply with Pong (0x8A)
                const pong = Buffer.from([0x8A, 0]);
                try { this.socket.write(pong); } catch (_) {}
            } else if (opcode === 0x1) {
                // Text frame
                const str = rawPayload.toString('utf8');
                try {
                    const parsed = JSON.parse(str);
                    this.emit('message', parsed);
                } catch (_) {
                    this.emit('message', str);
                }
            } else if (opcode === 0x2) {
                // Binary frame
                this.emit('binary', rawPayload);
            }
        }
    }
}

class WebSocketServer {
    constructor(httpServer) {
        this.clients = new Set();
        this.listeners = {};

        httpServer.on('upgrade', (req, socket, head) => {
            const key = req.headers['sec-websocket-key'];
            if (!key) {
                socket.destroy();
                return;
            }

            const acceptKey = crypto
                .createHash('sha1')
                .update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11')
                .digest('base64');

            const headers = [
                'HTTP/1.1 101 Switching Protocols',
                'Upgrade: websocket',
                'Connection: Upgrade',
                `Sec-WebSocket-Accept: ${acceptKey}`
            ];

            socket.write(headers.join('\r\n') + '\r\n\r\n');

            const client = new WSClient(socket);
            this.clients.add(client);

            client.on('close', () => this.clients.delete(client));

            if (head && head.length > 0) {
                client.handleData(head);
            }

            this.emit('connection', client, req);
        });

        // Periodic ping to keep alive and clean up ghost connections
        setInterval(() => {
            const ping = Buffer.from([0x89, 0]);
            for (const client of this.clients) {
                try {
                    if (client.socket.destroyed || !client.socket.writable) {
                        this.clients.delete(client);
                    } else {
                        client.socket.write(ping);
                    }
                } catch (_) {
                    this.clients.delete(client);
                }
            }
        }, 15000);
    }

    on(event, fn) {
        if (!this.listeners[event]) this.listeners[event] = [];
        this.listeners[event].push(fn);
    }

    emit(event, ...args) {
        if (this.listeners[event]) {
            for (const fn of this.listeners[event]) fn(...args);
        }
    }

    broadcast(data) {
        for (const client of this.clients) {
            client.send(data);
        }
    }
}

module.exports = { WebSocketServer, WSClient };

@echo off
title NEON SLITHER - Cybernetic Arena Game
echo ========================================================
echo   Launching NEON SLITHER - Grow. Boost. Survive.
echo ========================================================

set TARGET_HTML="%~dp0index.html"
set TARGET_SERVER="%~dp0server.js"

set NODE_EXEC=node
where node >nul 2>nul
if %errorlevel% neq 0 (
    if exist "%APPDATA%\Antigravity\bin\agy-node.cmd" (
        set NODE_EXEC="%APPDATA%\Antigravity\bin\agy-node.cmd"
    ) else (
        echo [i] Node.js not detected. Opening game directly in your browser...
        start "" %TARGET_HTML%
        exit /b 0
    )
)

echo Starting 60 FPS arena server...
call %NODE_EXEC% %TARGET_SERVER%

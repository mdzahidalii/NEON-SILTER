/**
 * NEON SLITHER - Application Controller & State Machine
 * Handles:
 * - Loading Screen -> Main Menu -> Playing -> Paused -> Game Over
 * - Real-time Live Leaderboard
 * - Skin Customization & Live Canvas Preview
 * - Procedural Audio (Sound FX & Synth Music)
 * - Settings & High Scores with localStorage persistence
 * - Desktop (Mouse / WASD / Space) & Mobile (Touch Drag / Joystick) Controls
 */

import { GameEngine } from './game-engine.js';
import { SoundEngine } from './audio.js';

class NeonSlitherApp {
    constructor() {
        this.sound = new SoundEngine();

        // Canvas element
        this.gameCanvas = document.getElementById('game-canvas');

        // Core Game Engine
        this.game = new GameEngine(this.gameCanvas);

        // App States: 'loading', 'menu', 'playing', 'paused', 'game_over'
        this.gameState = 'loading';

        // Stored Preferences
        this.loadSavedData();

        // Mobile joystick state
        this.joystickState = {
            active: false,
            touchId: null,
            startX: 0,
            startY: 0
        };

        this.init();
    }

    loadSavedData() {
        // Player callsign
        this.savedPlayerName = localStorage.getItem('neon_slither_name') || 'NeonGlow';
        
        // Selected skin index
        const savedSkin = parseInt(localStorage.getItem('neon_slither_skin'), 10);
        this.savedSkinIndex = !isNaN(savedSkin) && savedSkin >= 0 && savedSkin < this.game.skins.length ? savedSkin : 0;
        this.game.selectedSkinIndex = this.savedSkinIndex;

        // Best score
        this.bestScore = parseInt(localStorage.getItem('neon_slither_best_score'), 10) || 0;

        // Settings
        const savedSound = localStorage.getItem('neon_slither_sound');
        if (savedSound !== null) this.sound.soundEnabled = savedSound === 'true';

        const savedMusic = localStorage.getItem('neon_slither_music');
        if (savedMusic !== null) this.sound.musicEnabled = savedMusic === 'true';

        const savedQuality = localStorage.getItem('neon_slither_quality');
        if (savedQuality) this.game.graphicsQuality = savedQuality;

        const savedSens = parseFloat(localStorage.getItem('neon_slither_sens'));
        if (!isNaN(savedSens)) this.game.turnSensitivity = savedSens;
    }

    saveData() {
        localStorage.setItem('neon_slither_name', this.savedPlayerName);
        localStorage.setItem('neon_slither_skin', this.game.selectedSkinIndex);
        localStorage.setItem('neon_slither_best_score', this.bestScore);
        localStorage.setItem('neon_slither_sound', this.sound.soundEnabled);
        localStorage.setItem('neon_slither_music', this.sound.musicEnabled);
        localStorage.setItem('neon_slither_quality', this.game.graphicsQuality);
        localStorage.setItem('neon_slither_sens', this.game.turnSensitivity);
    }

    init() {
        this.bindGameEvents();
        this.bindUI();
        this.bindKeyboardShortcuts();
        this.bindMobileControls();
        this.renderSkinPreview();

        // Start background ambient bot arena for main menu visual (isMenuDemo = true)
        this.game.startNewGame(this.savedPlayerName, 12, true);

        // Frame loop for HUD & Live Leaderboard
        this.game.onFrame = (dt) => {
            if (this.gameState === 'playing') {
                this.updateHUD();
                this.updateLeaderboard();
            }
        };

        // Instantly display Main Menu with no loading screen delay
        const loadingScreen = document.getElementById('loading-screen');
        if (loadingScreen) {
            loadingScreen.style.display = 'none';
        }
        this.showMainMenu();
    }

    showMainMenu() {
        this.gameState = 'menu';
        document.getElementById('hud-layer').classList.add('hidden');
        document.getElementById('pause-modal').classList.add('hidden');
        document.getElementById('death-screen').classList.add('hidden');
        document.getElementById('skin-modal').classList.add('hidden');
        document.getElementById('help-modal').classList.add('hidden');
        document.getElementById('settings-modal').classList.add('hidden');
        document.getElementById('main-menu').classList.remove('hidden');

        // Sync inputs
        const nameInput = document.getElementById('menu-player-name');
        if (nameInput) nameInput.value = this.savedPlayerName;
        this.updateMenuSkinDisplay();
    }

    startGame() {
        const nameInput = document.getElementById('menu-player-name');
        const pName = nameInput ? nameInput.value.trim() || 'NeonGlow' : 'NeonGlow';
        this.savedPlayerName = pName;
        this.saveData();

        this.gameState = 'playing';

        // Hide overlay modals
        document.getElementById('main-menu').classList.add('hidden');
        document.getElementById('death-screen').classList.add('hidden');
        document.getElementById('pause-modal').classList.add('hidden');
        document.getElementById('hud-layer').classList.remove('hidden');

        // Start active live multiplayer game session
        this.game.startNewGame(pName, 24, false);

        // Start audio
        this.sound.init();
        if (this.sound.musicEnabled && !this.sound.isMuted) {
            this.sound.startMusic();
        }
    }

    pauseGame() {
        if (this.gameState !== 'playing') return;
        this.gameState = 'paused';
        this.game.pause();
        this.sound.playPause();

        const p = this.game.player;
        if (p) {
            document.getElementById('pause-stat-score').textContent = p.score;
            document.getElementById('pause-stat-length').textContent = Math.round(p.length);
            document.getElementById('pause-stat-kills').textContent = p.kills;
            const rankEl = document.getElementById('hud-rank');
            document.getElementById('pause-stat-rank').textContent = rankEl ? rankEl.textContent.split(' ')[0] : '#1';
        }

        document.getElementById('pause-modal').classList.remove('hidden');
    }

    resumeGame() {
        if (this.gameState !== 'paused') return;
        this.gameState = 'playing';
        this.game.resume();
        this.sound.playResume();
        document.getElementById('pause-modal').classList.add('hidden');
    }

    bindGameEvents() {
        this.game.onPlayerEat = (food, isWisp = false) => {
            if (isWisp) {
                this.sound.playWisp();
            } else {
                this.sound.playEat(food.type === 'death' || food.type === 'large');
            }
        };

        this.game.onBoostChange = (isBoosting) => {
            if (isBoosting && this.gameState === 'playing') {
                this.sound.startBoost();
            } else {
                this.sound.stopBoost();
            }
        };

        this.game.onKill = (victim) => {
            this.sound.playKill();
            this.showKillFeed(`ELIMINATED ${victim.name}`);
        };

        this.game.onKillFeed = (feed) => {
            this.showKillFeed(feed.text || feed);
        };

        this.game.onPlayerDeath = (player, reason, killerName) => {
            if (this.gameState !== 'playing') return;
            this.gameState = 'game_over';
            this.sound.stopBoost();
            this.sound.playDeath();

            // Update high score
            if (player.score > this.bestScore) {
                this.bestScore = player.score;
                this.saveData();
            }

            this.showDeathScreen(player, reason, killerName);
        };
    }

    bindUI() {
        // ==========================================
        // 1. MAIN MENU CONTROLS
        // ==========================================
        const btnMenuPlay = document.getElementById('btn-menu-play');
        if (btnMenuPlay) {
            btnMenuPlay.addEventListener('click', () => {
                this.sound.playClick();
                this.startGame();
            });
        }

        const btnOpenSkins = document.getElementById('btn-open-skins');
        if (btnOpenSkins) {
            btnOpenSkins.addEventListener('click', () => {
                this.sound.playClick();
                this.openSkinModal();
            });
        }

        const btnOpenSettings = document.getElementById('btn-open-settings');
        if (btnOpenSettings) {
            btnOpenSettings.addEventListener('click', () => {
                this.sound.playClick();
                this.openSettingsModal();
            });
        }

        const btnOpenHelp = document.getElementById('btn-open-help');
        if (btnOpenHelp) {
            btnOpenHelp.addEventListener('click', () => {
                this.sound.playClick();
                document.getElementById('help-modal').classList.remove('hidden');
            });
        }

        // Menu Sound Toggle
        const menuSoundBtn = document.getElementById('btn-menu-sound');
        if (menuSoundBtn) {
            menuSoundBtn.addEventListener('click', () => {
                const enabled = this.sound.toggleSound();
                this.saveData();
                this.updateSoundButtons(enabled);
                this.sound.playClick();
            });
        }

        // Menu Music Toggle
        const menuMusicBtn = document.getElementById('btn-menu-music');
        if (menuMusicBtn) {
            menuMusicBtn.addEventListener('click', () => {
                const enabled = this.sound.toggleMusic();
                this.saveData();
                this.updateMusicButtons(enabled);
                this.sound.playClick();
            });
        }

        // ==========================================
        // 2. HUD CONTROLS
        // ==========================================
        const hudSoundBtn = document.getElementById('btn-hud-sound');
        if (hudSoundBtn) {
            hudSoundBtn.addEventListener('click', () => {
                const enabled = this.sound.toggleSound();
                this.saveData();
                this.updateSoundButtons(enabled);
                this.sound.playClick();
            });
        }

        const hudMusicBtn = document.getElementById('btn-hud-music');
        if (hudMusicBtn) {
            hudMusicBtn.addEventListener('click', () => {
                const enabled = this.sound.toggleMusic();
                this.saveData();
                this.updateMusicButtons(enabled);
                this.sound.playClick();
            });
        }

        const hudPauseBtn = document.getElementById('btn-hud-pause');
        if (hudPauseBtn) {
            hudPauseBtn.addEventListener('click', () => this.pauseGame());
        }

        const hudSettingsBtn = document.getElementById('btn-hud-settings');
        if (hudSettingsBtn) {
            hudSettingsBtn.addEventListener('click', () => {
                this.sound.playClick();
                this.openSettingsModal();
            });
        }

        const hudFullscreenBtn = document.getElementById('btn-hud-fullscreen');
        if (hudFullscreenBtn) {
            hudFullscreenBtn.addEventListener('click', () => {
                this.toggleFullscreen();
                this.sound.playClick();
            });
        }

        const toggleLbBtn = document.getElementById('btn-toggle-lb');
        const lbCard = document.getElementById('leaderboard-card');
        if (toggleLbBtn && lbCard) {
            toggleLbBtn.addEventListener('click', () => {
                this.sound.playClick();
                const isHidden = lbCard.style.display === 'none';
                lbCard.style.display = isHidden ? 'block' : 'none';
                toggleLbBtn.classList.toggle('active', isHidden);
            });
        }

        // ==========================================
        // 3. PAUSE MODAL ACTIONS
        // ==========================================
        const btnPauseResume = document.getElementById('btn-pause-resume');
        if (btnPauseResume) btnPauseResume.addEventListener('click', () => this.resumeGame());

        const btnPauseRestart = document.getElementById('btn-pause-restart');
        if (btnPauseRestart) {
            btnPauseRestart.addEventListener('click', () => {
                this.sound.playClick();
                this.startGame();
            });
        }

        const btnPauseSettings = document.getElementById('btn-pause-settings');
        if (btnPauseSettings) {
            btnPauseSettings.addEventListener('click', () => {
                this.sound.playClick();
                this.openSettingsModal();
            });
        }

        const btnPauseMenu = document.getElementById('btn-pause-menu');
        if (btnPauseMenu) {
            btnPauseMenu.addEventListener('click', () => {
                this.sound.playClick();
                this.showMainMenu();
            });
        }

        // ==========================================
        // 4. SKIN CUSTOMIZER MODAL
        // ==========================================
        const closeSkinsBtn = document.getElementById('btn-close-skins');
        const saveSkinBtn = document.getElementById('btn-save-skin');
        const skinModal = document.getElementById('skin-modal');

        const closeSkinModal = () => {
            this.sound.playClick();
            skinModal.classList.add('hidden');
            this.updateMenuSkinDisplay();
        };

        if (closeSkinsBtn) closeSkinsBtn.addEventListener('click', closeSkinModal);
        if (saveSkinBtn) saveSkinBtn.addEventListener('click', closeSkinModal);

        const skinCards = document.querySelectorAll('.skin-card');
        skinCards.forEach(card => {
            card.addEventListener('click', () => {
                this.sound.playClick();
                const skinIdx = parseInt(card.dataset.skin, 10);
                if (!isNaN(skinIdx)) {
                    skinCards.forEach(c => c.classList.remove('active'));
                    card.classList.add('active');
                    this.game.selectedSkinIndex = skinIdx;
                    this.saveData();
                    this.renderSkinPreview();
                    if (this.game.player) {
                        this.game.player.skin = this.game.skins[skinIdx];
                    }
                }
            });
        });

        // ==========================================
        // 5. SETTINGS MODAL ACTIONS
        // ==========================================
        const closeSettingsBtn = document.getElementById('btn-close-settings');
        const settingsDoneBtn = document.getElementById('btn-settings-done');
        const settingsModal = document.getElementById('settings-modal');

        const closeSettings = () => {
            this.sound.playClick();
            settingsModal.classList.add('hidden');
        };

        if (closeSettingsBtn) closeSettingsBtn.addEventListener('click', closeSettings);
        if (settingsDoneBtn) settingsDoneBtn.addEventListener('click', closeSettings);

        const settingToggleSound = document.getElementById('setting-toggle-sound');
        if (settingToggleSound) {
            settingToggleSound.addEventListener('click', () => {
                const enabled = this.sound.toggleSound();
                this.saveData();
                this.updateSoundButtons(enabled);
            });
        }

        const settingToggleMusic = document.getElementById('setting-toggle-music');
        if (settingToggleMusic) {
            settingToggleMusic.addEventListener('click', () => {
                const enabled = this.sound.toggleMusic();
                this.saveData();
                this.updateMusicButtons(enabled);
            });
        }

        const qualityBtns = document.querySelectorAll('.seg-btn');
        qualityBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                this.sound.playClick();
                qualityBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.game.graphicsQuality = btn.dataset.quality;
                this.saveData();
            });
        });

        const sensSlider = document.getElementById('setting-sens-slider');
        const sensVal = document.getElementById('setting-sens-val');
        if (sensSlider && sensVal) {
            sensSlider.value = this.game.turnSensitivity;
            sensVal.textContent = `${this.game.turnSensitivity.toFixed(1)}x`;
            sensSlider.addEventListener('input', (e) => {
                const val = parseFloat(e.target.value);
                sensVal.textContent = `${val.toFixed(1)}x`;
                this.game.turnSensitivity = val;
                this.saveData();
            });
        }

        const settingJoystickBtn = document.getElementById('setting-toggle-joystick');
        const mobileZone = document.getElementById('mobile-controls-zone');
        if (settingJoystickBtn) {
            settingJoystickBtn.addEventListener('click', () => {
                this.sound.playClick();
                const cur = settingJoystickBtn.textContent;
                if (cur === 'AUTO') {
                    settingJoystickBtn.textContent = 'ALWAYS';
                    if (mobileZone) mobileZone.style.display = 'block';
                } else if (cur === 'ALWAYS') {
                    settingJoystickBtn.textContent = 'OFF';
                    if (mobileZone) mobileZone.style.display = 'none';
                } else {
                    settingJoystickBtn.textContent = 'AUTO';
                    if (mobileZone) mobileZone.style.display = window.innerWidth <= 660 ? 'block' : 'none';
                }
            });
        }

        const settingFullscreenBtn = document.getElementById('setting-toggle-fullscreen');
        if (settingFullscreenBtn) {
            settingFullscreenBtn.addEventListener('click', () => {
                this.toggleFullscreen();
                settingFullscreenBtn.textContent = document.fullscreenElement ? 'EXIT' : 'ENTER';
            });
        }

        const settingResetBtn = document.getElementById('btn-settings-reset');
        if (settingResetBtn) {
            settingResetBtn.addEventListener('click', () => {
                this.sound.playClick();
                this.sound.soundEnabled = true;
                this.sound.musicEnabled = true;
                this.game.graphicsQuality = 'high';
                this.game.turnSensitivity = 1.0;
                this.saveData();
                this.syncSettingsUI();
            });
        }

        // ==========================================
        // 6. HOW TO PLAY MODAL ACTIONS
        // ==========================================
        const closeHelpBtn = document.getElementById('btn-close-help');
        const helpPlayBtn = document.getElementById('btn-help-play');
        const helpModal = document.getElementById('help-modal');

        if (closeHelpBtn) {
            closeHelpBtn.addEventListener('click', () => {
                this.sound.playClick();
                helpModal.classList.add('hidden');
            });
        }

        if (helpPlayBtn) {
            helpPlayBtn.addEventListener('click', () => {
                this.sound.playClick();
                helpModal.classList.add('hidden');
                this.startGame();
            });
        }

        // ==========================================
        // 7. GAME OVER ACTIONS
        // ==========================================
        const btnRespawn = document.getElementById('btn-respawn');
        if (btnRespawn) {
            btnRespawn.addEventListener('click', () => {
                this.sound.playClick();
                const deathNameInput = document.getElementById('death-player-name');
                if (deathNameInput) {
                    this.savedPlayerName = deathNameInput.value.trim() || 'NeonGlow';
                    this.saveData();
                }
                this.startGame();
            });
        }

        const btnGameOverMenu = document.getElementById('btn-gameover-menu');
        if (btnGameOverMenu) {
            btnGameOverMenu.addEventListener('click', () => {
                this.sound.playClick();
                this.showMainMenu();
            });
        }

        const btnGameOverSkin = document.getElementById('btn-gameover-skin');
        if (btnGameOverSkin) {
            btnGameOverSkin.addEventListener('click', () => {
                this.sound.playClick();
                this.openSkinModal();
            });
        }
    }

    openSkinModal() {
        document.getElementById('skin-modal').classList.remove('hidden');
        const skinCards = document.querySelectorAll('.skin-card');
        skinCards.forEach(c => {
            const idx = parseInt(c.dataset.skin, 10);
            c.classList.toggle('active', idx === this.game.selectedSkinIndex);
        });
        this.renderSkinPreview();
    }

    openSettingsModal() {
        this.syncSettingsUI();
        document.getElementById('settings-modal').classList.remove('hidden');
    }

    syncSettingsUI() {
        const toggleSound = document.getElementById('setting-toggle-sound');
        if (toggleSound) {
            toggleSound.textContent = this.sound.soundEnabled ? 'ON' : 'OFF';
            toggleSound.classList.toggle('active', this.sound.soundEnabled);
        }

        const toggleMusic = document.getElementById('setting-toggle-music');
        if (toggleMusic) {
            toggleMusic.textContent = this.sound.musicEnabled ? 'ON' : 'OFF';
            toggleMusic.classList.toggle('active', this.sound.musicEnabled);
        }

        const qualityBtns = document.querySelectorAll('.seg-btn');
        qualityBtns.forEach(btn => {
            btn.classList.toggle('active', btn.dataset.quality === this.game.graphicsQuality);
        });

        const sensSlider = document.getElementById('setting-sens-slider');
        const sensVal = document.getElementById('setting-sens-val');
        if (sensSlider && sensVal) {
            sensSlider.value = this.game.turnSensitivity;
            sensVal.textContent = `${this.game.turnSensitivity.toFixed(1)}x`;
        }
    }

    updateSoundButtons(enabled) {
        const menuSound = document.getElementById('btn-menu-sound');
        if (menuSound) {
            const lbl = menuSound.querySelector('.btn-label');
            if (lbl) lbl.textContent = enabled ? 'SOUND: ON' : 'SOUND: OFF';
            menuSound.classList.toggle('active', enabled);
        }

        const hudSound = document.getElementById('btn-hud-sound');
        if (hudSound) {
            hudSound.classList.toggle('active', enabled);
        }

        const settingSound = document.getElementById('setting-toggle-sound');
        if (settingSound) {
            settingSound.textContent = enabled ? 'ON' : 'OFF';
            settingSound.classList.toggle('active', enabled);
        }
    }

    updateMusicButtons(enabled) {
        const menuMusic = document.getElementById('btn-menu-music');
        if (menuMusic) {
            const lbl = menuMusic.querySelector('.btn-label');
            if (lbl) lbl.textContent = enabled ? 'MUSIC: ON' : 'MUSIC: OFF';
            menuMusic.classList.toggle('active', enabled);
        }

        const hudMusic = document.getElementById('btn-hud-music');
        if (hudMusic) {
            hudMusic.classList.toggle('active', enabled);
        }

        const settingMusic = document.getElementById('setting-toggle-music');
        if (settingMusic) {
            settingMusic.textContent = enabled ? 'ON' : 'OFF';
            settingMusic.classList.toggle('active', enabled);
        }
    }

    renderSkinPreview() {
        const skin = this.game.skins[this.game.selectedSkinIndex] || this.game.skins[0];

        // 1. Modal preview canvas
        const modalCanvas = document.getElementById('skin-preview-canvas');
        if (modalCanvas) {
            const ctx = modalCanvas.getContext('2d');
            const w = modalCanvas.width;
            const h = modalCanvas.height;
            ctx.clearRect(0, 0, w, h);
            ctx.fillStyle = '#f8fafc';
            ctx.fillRect(0, 0, w, h);

            // Draw serpentine demo snake
            const segments = 10;
            const segRadius = 11;
            const centerY = h / 2;

            for (let i = segments - 1; i >= 0; i--) {
                const t = i / segments;
                const sx = w - 45 - (i * 22);
                const sy = centerY + Math.sin(i * 0.7) * 12;

                ctx.fillStyle = t < 0.5 ? skin.primary : skin.secondary;
                ctx.beginPath();
                ctx.arc(sx, sy, segRadius * (0.8 + 0.2 * (1 - t)), 0, Math.PI * 2);
                ctx.fill();

                ctx.strokeStyle = 'rgba(15, 23, 42, 0.12)';
                ctx.lineWidth = 0.8;
                ctx.stroke();
            }

            // Head
            ctx.save();
            ctx.translate(w - 45, centerY);
            ctx.fillStyle = skin.primary;
            ctx.beginPath();
            ctx.ellipse(0, 0, 16, 13, 0, 0, Math.PI * 2);
            ctx.fill();

            ctx.strokeStyle = 'rgba(15, 23, 42, 0.16)';
            ctx.lineWidth = 1;
            ctx.stroke();

            // Eyes
            ctx.fillStyle = '#fff';
            ctx.beginPath();
            ctx.arc(5, -6, 4, 0, Math.PI * 2);
            ctx.arc(5, 6, 4, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = 'rgba(15, 23, 42, 0.2)';
            ctx.lineWidth = 0.75;
            ctx.stroke();

            ctx.fillStyle = '#0f172a';
            ctx.beginPath();
            ctx.arc(7, -6, 2.2, 0, Math.PI * 2);
            ctx.arc(7, 6, 2.2, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
        }

        const skinLabel = document.getElementById('skin-preview-label');
        if (skinLabel) skinLabel.textContent = skin.name;

        // 2. Menu preview canvas
        const menuCanvas = document.getElementById('menu-skin-canvas');
        if (menuCanvas) {
            const ctx = menuCanvas.getContext('2d');
            ctx.clearRect(0, 0, menuCanvas.width, menuCanvas.height);
            ctx.fillStyle = '#f8fafc';
            ctx.fillRect(0, 0, menuCanvas.width, menuCanvas.height);

            // Mini head & segment
            ctx.fillStyle = skin.secondary;
            ctx.beginPath();
            ctx.arc(18, 15, 8, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = 'rgba(15, 23, 42, 0.12)';
            ctx.lineWidth = 0.75;
            ctx.stroke();

            ctx.fillStyle = skin.primary;
            ctx.beginPath();
            ctx.arc(38, 15, 10, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = 'rgba(15, 23, 42, 0.15)';
            ctx.lineWidth = 1;
            ctx.stroke();

            ctx.fillStyle = '#fff';
            ctx.beginPath();
            ctx.arc(42, 11, 2.5, 0, Math.PI * 2);
            ctx.arc(42, 19, 2.5, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#0f172a';
            ctx.beginPath();
            ctx.arc(43, 11, 1.4, 0, Math.PI * 2);
            ctx.arc(43, 19, 1.4, 0, Math.PI * 2);
            ctx.fill();
        }

        const menuSkinName = document.getElementById('menu-skin-name');
        if (menuSkinName) menuSkinName.textContent = skin.name;
    }

    updateMenuSkinDisplay() {
        const skin = this.game.skins[this.game.selectedSkinIndex] || this.game.skins[0];
        const menuSkinName = document.getElementById('menu-skin-name');
        if (menuSkinName) menuSkinName.textContent = skin.name;
        this.renderSkinPreview();
    }

    toggleFullscreen() {
        if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen().catch(() => {});
        } else {
            document.exitFullscreen().catch(() => {});
        }
    }

    bindKeyboardShortcuts() {
        window.addEventListener('keydown', (e) => {
            const activeTag = document.activeElement ? document.activeElement.tagName.toLowerCase() : '';
            if (activeTag === 'input' || activeTag === 'textarea') return;

            if (e.code === 'Escape' || e.code === 'KeyP') {
                e.preventDefault();
                if (this.gameState === 'playing') {
                    this.pauseGame();
                } else if (this.gameState === 'paused') {
                    this.resumeGame();
                }
            } else if (e.code === 'KeyM') {
                const enabled = this.sound.toggleMusic();
                this.saveData();
                this.updateMusicButtons(enabled);
            } else if (e.code === 'KeyS' && e.code !== 'Space') {
                // S alone handled by WASD steering
            } else if (e.code === 'Space') {
                if (this.gameState === 'menu') {
                    e.preventDefault();
                    this.startGame();
                } else if (this.gameState === 'game_over') {
                    e.preventDefault();
                    this.startGame();
                }
            }
        });
    }

    bindMobileControls() {
        const controlsZone = document.getElementById('mobile-controls-zone');
        const joystickEl   = document.getElementById('virtual-joystick');
        const baseEl       = document.getElementById('joystick-base');
        const stickEl      = document.getElementById('joystick-stick');
        const boostBtn     = document.getElementById('mobile-boost-btn');

        if (!joystickEl || !stickEl || !controlsZone) return;

        // ---- Auto-detect touch device ----
        const isTouchDevice = () => (
            'ontouchstart' in window ||
            navigator.maxTouchPoints > 0 ||
            window.matchMedia('(hover: none) and (pointer: coarse)').matches
        );

        const showMobileControls = () => {
            controlsZone.style.display = 'block';
        };

        if (isTouchDevice()) {
            showMobileControls();
        } else {
            // Show controls the first time a touch event fires on desktop with touch screen
            window.addEventListener('touchstart', () => showMobileControls(), { once: true });
        }

        // ---- Joystick geometry ----
        // maxRadius is half the joystick element width (70px for 140px element)
        const getMaxRadius = () => joystickEl.offsetWidth * 0.50;

        // ---- Floating joystick: touch anywhere in the LEFT 60% of screen ----
        // The joystick base repositions to the touch origin so thumb never has to reach.
        const JOYSTICK_ZONE_RATIO = 0.60; // left 60% of screen triggers joystick

        const startJoystick = (touch) => {
            // Only claim touches in left portion of screen
            if (touch.clientX > window.innerWidth * JOYSTICK_ZONE_RATIO) return false;

            this.joystickState.active = true;
            this.joystickState.touchId = touch.identifier;

            // Reposition joystick base to touch origin (clamped inside screen)
            const r = getMaxRadius();
            const jw = joystickEl.offsetWidth;
            const jh = joystickEl.offsetHeight;
            const clampX = Math.max(jw / 2, Math.min(window.innerWidth * JOYSTICK_ZONE_RATIO - jw / 2, touch.clientX));
            const clampY = Math.max(jh / 2, Math.min(window.innerHeight - jh / 2, touch.clientY));

            joystickEl.style.position = 'fixed';
            joystickEl.style.left = `${clampX - jw / 2}px`;
            joystickEl.style.bottom = 'auto';
            joystickEl.style.top  = `${clampY - jh / 2}px`;

            this.joystickState.startX = clampX;
            this.joystickState.startY = clampY;

            stickEl.style.transform = 'translate(-50%, -50%)';
            joystickEl.classList.add('active');
            return true;
        };

        const moveJoystick = (touch) => {
            if (!this.joystickState.active || touch.identifier !== this.joystickState.touchId) return;

            const dx = touch.clientX - this.joystickState.startX;
            const dy = touch.clientY - this.joystickState.startY;
            const dist = Math.hypot(dx, dy);
            const maxR = getMaxRadius();
            const clampedDist = Math.min(dist, maxR);
            const angle = Math.atan2(dy, dx);

            const knobX = Math.cos(angle) * clampedDist;
            const knobY = Math.sin(angle) * clampedDist;
            stickEl.style.transform = `translate(calc(-50% + ${knobX}px), calc(-50% + ${knobY}px))`;

            const normX = maxR > 0 ? (knobX / maxR) : 0;
            const normY = maxR > 0 ? (knobY / maxR) : 0;
            this.game.setJoystickInput(normX, normY);
        };

        const endJoystick = () => {
            if (!this.joystickState.active) return;
            this.joystickState.active = false;
            this.joystickState.touchId = null;

            // Reset knob to center
            stickEl.style.transform = 'translate(-50%, -50%)';
            joystickEl.classList.remove('active');

            // Drift back to default bottom-left position smoothly
            joystickEl.style.position  = '';
            joystickEl.style.left      = '';
            joystickEl.style.top       = '';
            joystickEl.style.bottom    = '';

            this.game.setJoystickInput(0, 0);
        };

        // Touch start: claim joystick touches on left half of screen
        window.addEventListener('touchstart', (e) => {
            for (let i = 0; i < e.changedTouches.length; i++) {
                const t = e.changedTouches[i];
                if (!this.joystickState.active) {
                    if (startJoystick(t)) break;
                }
            }
        }, { passive: true });

        window.addEventListener('touchmove', (e) => {
            if (!this.joystickState.active) return;
            for (let i = 0; i < e.changedTouches.length; i++) {
                moveJoystick(e.changedTouches[i]);
            }
            e.preventDefault();
        }, { passive: false });

        window.addEventListener('touchend', (e) => {
            for (let i = 0; i < e.changedTouches.length; i++) {
                if (e.changedTouches[i].identifier === this.joystickState.touchId) {
                    endJoystick();
                    break;
                }
            }
        }, { passive: true });

        window.addEventListener('touchcancel', (e) => {
            for (let i = 0; i < e.changedTouches.length; i++) {
                if (e.changedTouches[i].identifier === this.joystickState.touchId) {
                    endJoystick();
                    break;
                }
            }
        }, { passive: true });

        // ---- Boost Button ----
        if (boostBtn) {
            boostBtn.addEventListener('touchstart', (e) => {
                this.game.setPlayerBoosting(true);
                boostBtn.classList.add('pressing');
                e.preventDefault();
            }, { passive: false });

            boostBtn.addEventListener('touchend', (e) => {
                this.game.setPlayerBoosting(false);
                boostBtn.classList.remove('pressing');
                e.preventDefault();
            }, { passive: false });

            boostBtn.addEventListener('touchcancel', () => {
                this.game.setPlayerBoosting(false);
                boostBtn.classList.remove('pressing');
            }, { passive: true });
        }
    }

    updateHUD() {
        if (!this.game.player) return;

        const p = this.game.player;
        const scoreEl = document.getElementById('hud-score');
        const lengthEl = document.getElementById('hud-length');
        const killsEl = document.getElementById('hud-kills');
        const fpsEl = document.getElementById('hud-fps');
        const boostBar = document.getElementById('boost-bar-fill');
        const rankEl = document.getElementById('hud-rank');

        if (scoreEl) {
            if (this.lastScore !== undefined && p.score > this.lastScore) {
                scoreEl.classList.remove('score-tick');
                void scoreEl.offsetWidth; // trigger reflow
                scoreEl.classList.add('score-tick');
            }
            this.lastScore = p.score;
            scoreEl.textContent = p.score;
        }

        if (lengthEl) lengthEl.textContent = Math.round(p.length);
        if (killsEl) killsEl.textContent = p.kills;
        if (fpsEl) fpsEl.textContent = `${this.game.fps} FPS`;
        if (boostBar) boostBar.style.width = `${p.boostEnergy}%`;

        // Calculate rank among alive snakes or use server rank
        if (rankEl) {
            if (this.game.isMultiplayer && p.rank) {
                rankEl.textContent = `#${p.rank} / ${this.game.totalPlayers || this.game.snakes.length}`;
            } else {
                const alive = this.game.snakes.filter(s => s.isAlive);
                alive.sort((a, b) => b.score - a.score);
                const myRank = alive.indexOf(p) + 1;
                rankEl.textContent = `#${myRank > 0 ? myRank : 1} / ${alive.length}`;
            }
        }

        // Multiplayer live status indicator
        const netIndicator = document.getElementById('hud-multiplayer-indicator');
        if (netIndicator) {
            const netText = netIndicator.querySelector('.net-text');
            if (this.game.isMultiplayer && this.game.multiplayerConnected) {
                if (netText) netText.textContent = 'LIVE MULTIPLAYER';
                netIndicator.style.color = 'var(--neon-green)';
                netIndicator.style.borderColor = 'rgba(0, 255, 102, 0.4)';
            } else {
                if (netText) netText.textContent = 'SOLO ARENA';
                netIndicator.style.color = 'var(--neon-cyan)';
                netIndicator.style.borderColor = 'rgba(0, 240, 255, 0.3)';
            }
        }
    }

    updateLeaderboard() {
        const lbList = document.getElementById('leaderboard-list');
        if (!lbList) return;

        let top10 = [];
        let playerRank = 1;
        let isPlayerOutsideTop10 = false;

        if (this.game.isMultiplayer && this.game.topLeaderboard.length > 0) {
            top10 = this.game.topLeaderboard;
            if (this.game.player) {
                playerRank = this.game.player.rank || 1;
                isPlayerOutsideTop10 = playerRank > 10;
            }
        } else if (this.game.snakes) {
            const alive = this.game.snakes.filter(s => s.isAlive);
            alive.sort((a, b) => b.score - a.score);
            top10 = alive.slice(0, 10).map((s, idx) => ({
                rank: idx + 1,
                id: s.id,
                name: s.name,
                score: s.score,
                isPlayer: s.isPlayer
            }));
            if (this.game.player && this.game.player.isAlive) {
                const pIdx = alive.indexOf(this.game.player);
                playerRank = pIdx + 1;
                isPlayerOutsideTop10 = pIdx >= 10;
            }
        }

        const maxScore = top10.length > 0 ? (top10[0].score || 1) : 1;
        let html = '';
        for (let i = 0; i < top10.length; i++) {
            const row = top10[i];
            const isMe = row.isPlayer || (this.game.player && row.id === this.game.player.id);
            const rank = row.rank || (i + 1);
            const nameDisplay = isMe ? `${row.name} (YOU)` : row.name;
            const pct = Math.min(100, Math.round((row.score / maxScore) * 100));

            html += `
                <div class="lb-row ${isMe ? 'lb-player' : ''}">
                    <div style="position: absolute; left: 0; top: 0; bottom: 0; width: ${pct}%; background: ${isMe ? 'rgba(37, 99, 235, 0.09)' : 'rgba(15, 23, 42, 0.03)'}; pointer-events: none; z-index: 0;"></div>
                    <span class="lb-rank" style="position: relative; z-index: 1;">#${rank}</span>
                    <span class="lb-name" style="position: relative; z-index: 1;" title="${row.name}">${nameDisplay}</span>
                    <span class="lb-score font-mono" style="position: relative; z-index: 1;">${row.score}</span>
                </div>
            `;
        }

        // If player is outside top 10, pin player's row at bottom
        if (isPlayerOutsideTop10 && this.game.player && this.game.player.isAlive) {
            const p = this.game.player;
            const pct = Math.min(100, Math.round((p.score / maxScore) * 100));
            html += `
                <div style="border-top: 1px dashed rgba(15, 23, 42, 0.12); margin: 3px 0;"></div>
                <div class="lb-row lb-player">
                    <div style="position: absolute; left: 0; top: 0; bottom: 0; width: ${pct}%; background: rgba(37, 99, 235, 0.09); pointer-events: none; z-index: 0;"></div>
                    <span class="lb-rank" style="position: relative; z-index: 1;">#${playerRank}</span>
                    <span class="lb-name" style="position: relative; z-index: 1;">${p.name} (YOU)</span>
                    <span class="lb-score font-mono" style="position: relative; z-index: 1;">${p.score}</span>
                </div>
            `;
        }

        lbList.innerHTML = html;
    }

    showKillFeed(msg) {
        const feed = document.getElementById('kill-feed');
        if (!feed) return;

        const item = document.createElement('div');
        item.className = 'kill-feed-item';
        item.textContent = typeof msg === 'string' ? msg : msg.text;
        feed.appendChild(item);

        setTimeout(() => {
            item.classList.add('fade-out');
            setTimeout(() => item.remove(), 400);
        }, 2600);
    }

    showDeathScreen(player, reason, killerName) {
        const deathScreen = document.getElementById('death-screen');
        if (!deathScreen) return;

        deathScreen.classList.remove('hidden');
        document.getElementById('death-score').textContent = player.score;
        document.getElementById('death-length').textContent = Math.round(player.length);
        document.getElementById('death-best').textContent = this.bestScore;

        const killsEl = document.getElementById('death-kills');
        if (killsEl) killsEl.textContent = player.kills || 0;

        const mins = Math.floor((player.survivalTime || 0) / 60);
        const secs = Math.floor((player.survivalTime || 0) % 60);
        const timeStr = `${mins < 10 ? '0' : ''}${mins}:${secs < 10 ? '0' : ''}${secs}`;
        const timeEl = document.getElementById('death-time');
        if (timeEl) timeEl.textContent = timeStr;
        
        const rankEl = document.getElementById('hud-rank');
        document.getElementById('death-rank').textContent = rankEl ? rankEl.textContent.split(' ')[0] : '#1';

        const reasonEl = document.getElementById('death-reason');
        if (reasonEl) {
            if (killerName) {
                reasonEl.textContent = `ELIMINATED BY ${killerName.toUpperCase()}`;
            } else if (reason === "boundary") {
                reasonEl.textContent = "COLLISION WITH ARENA PERIMETER";
            } else {
                reasonEl.textContent = "COLLISION WITH ENEMY SNAKE BODY";
            }
        }

        const deathNameInput = document.getElementById('death-player-name');
        if (deathNameInput) deathNameInput.value = this.savedPlayerName;
    }
}

// Launch on DOM ready
window.addEventListener('DOMContentLoaded', () => {
    window.app = new NeonSlitherApp();
});
